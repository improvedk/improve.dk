using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Shortest_Path
{
	public class Line2D
	{
		public Point2D P1, P2;
		private double length;
		private bool isHorizontal;
		private bool isVertical;
		Point2D midPoint;
		private double lineSlope;

		public Line2D(Point2D p1, Point2D p2)
		{
			this.P1 = p1;
			this.P2 = p2;

			init();
		}

		public Line2D(Point p1, Point p2)
		{
			this.P1 = new Point2D(p1.X, p1.Y);
			this.P2 = new Point2D(p2.X, p2.Y);

			init();
		}

		private void init()
		{
			length = P1.DistanceTo(P2);
			isHorizontal = P1.Y == P2.Y;
			isVertical = P1.X == P2.X;
			midPoint = new Point2D(((P1.X + P2.X) / 2), ((P1.Y + P2.Y) / 2));
			lineSlope = (P2.Y - P1.Y) / (P2.X - P1.X);
		}

		public override int GetHashCode()
		{
			return P1.GetHashCode() ^ P2.GetHashCode();
		}

		public double LineSlope
		{
			get
			{
				if (isVertical)
					throw new Exception("Slope cannot be calculated for vertical lines.");

				return lineSlope;
			}
		}

		public double Length
		{
			get { return length; }
		}

		public bool IsHorizontal
		{
			get { return isHorizontal; }
		}

		public bool IsVertical
		{
			get { return isVertical; }
		}

		public Point2D MidPoint
		{
			get { return midPoint; }
		}

		public bool IsParallelWith(Line2D l)
		{
			return LineSlope == l.LineSlope;
		}

		public bool IsPerpendicularWith(Line2D l)
		{
			return LineSlope * l.LineSlope == -1;
		}

		private double triangleArea(Point2D p1, Point2D p2, Point2D p3)
		{
			return (p3.Y - p1.Y) * (p2.X - p1.X) - (p3.X - p1.X) * (p2.Y - p1.Y);
		}

		public override string ToString()
		{
			return "(" + P1.X + "," + P1.Y + "),(" + P2.X + "," + P2.Y + ")";
		}

		public Line2D CreateRayLine(double length)
		{
			return new Line2D(midPoint, new Point2D(midPoint.X + length, midPoint.Y));
		}

		public bool IntersectsWith(Line2D l)
		{
			// Check for coincident lines
			if (Equals(l))
				return true;

			// Check for parallel horizontal/vertical lines
			if (isVertical && l.IsVertical)
				return false;

			if (isHorizontal && l.IsHorizontal)
				return false;

			// If the product of the two triangle areas is less than 0, the the lines intersect
			if (triangleArea(P1, P2, l.P1) * triangleArea(P1, P2, l.P2) < 0)
				if (triangleArea(l.P1, l.P2, P1) * triangleArea(l.P1, l.P2, P2) < 0)
					return true;

			return false;
		}

		public override bool Equals(object obj)
		{
			Line2D l = (Line2D)obj;

			return l.P1 == P1 && l.P2 == P2;
		}
	}

	public class Polygon2D
	{
		private List<Point> points = new List<Point>();

		public List<Point> Points
		{
			get { return points; }
		}

		public void AddPoint(Point p)
		{
			points.Add(p);
		}

		public Point[] ToArray()
		{
			return points.ToArray();
		}

		public bool ContainsPoint(Point p)
		{
			Point[] poly = this.ToArray();
			Point p1, p2;
			bool inside = false;
			Point oldPoint = new Point(poly[poly.Length - 1].X, poly[poly.Length - 1].Y);

			for (int i = 0; i < poly.Length; i++)
			{
				Point newPoint = new Point(poly[i].X, poly[i].Y);

				if (newPoint.X > oldPoint.X)
				{
					p1 = oldPoint;
					p2 = newPoint;
				}
				else
				{
					p1 = newPoint;
					p2 = oldPoint;
				}

				if ((newPoint.X < p.X) == (p.X <= oldPoint.X) && ((long)p.Y - (long)p1.Y) * (long)(p2.X - p1.X) < ((long)p2.Y - (long)p1.Y) * (long)(p.X - p1.X))
					inside = !inside;

				oldPoint = newPoint;
			}

			return inside;
		}
	}

	public class Point2D
	{
		public double X;
		public double Y;
		public double Value = 0;

		public override int GetHashCode()
		{
			return Convert.ToInt32(X) * Convert.ToInt32(Y);
		}

		public Point2D(double x, double y)
		{
			this.X = x;
			this.Y = y;
		}

		public Point ToPoint()
		{
			return new Point(Convert.ToInt32(X), Convert.ToInt32(Y));
		}

		public override bool Equals(object obj)
		{
			Point2D p = (Point2D)obj;

			return p.X == X && p.Y == Y;
		}

		public double DistanceTo(Point2D p)
		{
			return Math.Abs(Math.Sqrt(Math.Pow(p.X - X, 2) + Math.Pow(p.Y - Y, 2)));
		}
	}
}