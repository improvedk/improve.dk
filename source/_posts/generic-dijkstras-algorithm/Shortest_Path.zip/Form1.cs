using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using Improve.Framework.Algorithms;

namespace Shortest_Path
{
	public partial class Form1 : Form
	{
		List<Polygon2D> polygons = new List<Polygon2D>();
		Brush pointBrush = new SolidBrush(Color.Blue);
		Brush polygonPointBrush = new SolidBrush(Color.Red);
		Brush blackBrush = new SolidBrush(Color.Black);
		Brush grayBrush = new SolidBrush(Color.Gray);
		Brush beigeBrush = new SolidBrush(Color.Beige);
		Pen mouseConnectionsPen = new Pen(new SolidBrush(Color.Coral));
		Pen blackPen = new Pen(new SolidBrush(Color.Black));
		Pen bluePen = new Pen(new SolidBrush(Color.Blue));
		Pen grayPen = new Pen(new SolidBrush(Color.DarkGray));
		Font textFont = new Font(FontFamily.GenericSansSerif, 8);
		Font smallTextFont = new Font(FontFamily.GenericSansSerif, 6);
		Dictionary<Point2D, List<Point2D>> fixedConnections = new Dictionary<Point2D, List<Point2D>>();
		List<Point2D> fixedPoints = new List<Point2D>();
		Bitmap baseBitmap;
		Point2D targetPoint = new Point2D(350, 150);

		private void connectPoints(Point p1, Point p2, Graphics g)
		{
			g.DrawLine(grayPen, p1, p2);

			// Draw line length
			if (chkDrawConnectorLineLengths.Checked)
			{
				Line2D l = new Line2D(p1, p2);
				g.DrawString(Math.Round(l.Length, 1).ToString(), textFont, blackBrush, new PointF(Convert.ToInt32(l.MidPoint.X), Convert.ToInt32(l.MidPoint.Y)));
			}
		}

		private void drawPolygon(Polygon2D poly, Graphics g)
		{
			g.FillPolygon(grayBrush, poly.ToArray());
			g.DrawPolygon(blackPen, poly.ToArray());

			foreach(Point p in poly.Points)
				g.FillEllipse(polygonPointBrush, new Rectangle(p.X-4, p.Y-4, 8, 8));
		}

		private void drawPoint(Point p, Graphics g)
		{
			g.FillEllipse(pointBrush, new Rectangle(p.X - 4, p.Y - 4, 8, 8));
		}

		private bool intersectsAnyPolygons(Line2D l, List<Polygon2D> polygons)
		{
			foreach (Polygon2D poly in polygons)
			{
				Line2D ray = l.CreateRayLine(pb.Width);
				int rayCrossings = 0;

				// Check if we intercept any lines
				for (int i = 1; i < poly.Points.Count; i++)
				{
					Line2D intersectLine = new Line2D(poly.Points[i - 1], poly.Points[i]);

					if (l.IntersectsWith(intersectLine))
						return true;
					else
						if (ray.IntersectsWith(intersectLine))
							rayCrossings++;
				}

				Line2D intersectLine2 = new Line2D(poly.Points[0], poly.Points[poly.Points.Count - 1]);
				if (l.IntersectsWith(intersectLine2))
					return true;
				else
					if (ray.IntersectsWith(intersectLine2))
						rayCrossings++;

				if (rayCrossings % 2 != 0)
					return true;
			}

			return false;
		}

		private void draw(Point2D mouse, Point2D target)
		{
			Bitmap bmp = (Bitmap)baseBitmap.Clone();
			Graphics g = Graphics.FromImage(bmp);
			
			// Draw points
			drawPoint(mouse.ToPoint(), g);
			drawPoint(target.ToPoint(), g);

			// Create allPoints array
			List<Point2D> allPoints = new List<Point2D>(fixedPoints);
			allPoints.Add(mouse);
			allPoints.Add(target);

			// Connect mouse & target points to all other points
			Dictionary<Point2D, List<Point2D>> connections = copyConnections(fixedConnections);
			if(!connections.ContainsKey(mouse))
				connections.Add(mouse, new List<Point2D>());
			if(!connections.ContainsKey(target))
				connections.Add(target, new List<Point2D>());
			foreach (Point2D p1 in new List<Point2D>() { mouse, target })
			{
				// If point is inside a polygon, there can be no connections
				if (pointIsInPolygons(p1))
					continue;

				// p1 will never have a connection to itself, so only loop other points
				foreach (Point2D p2 in allPoints.Where(p => p != p1))
					if (!intersectsAnyPolygons(new Line2D(p1, p2), polygons))
					{
						connections[p1].Add(p2);
						connections[p2].Add(p1);
					}
			}

			// Run Dijkstra's algorithm
			List<Point2D> result = Dijkstra<Point2D>.ShortestPath(connections, mouse, target, (p1, p2) => p1 == p2, (p1, p2) => p1.DistanceTo(p2));

			// Draw (unique) connections
			if (chkDrawConnectorLines.Checked)
			{
				List<Line2D> drawnLines = new List<Line2D>();
				foreach (Point2D p1 in new Point2D[] { mouse, target })
				{
					foreach (Point2D p2 in connections[p1])
					{
						Line2D line = new Line2D(p1, p2);

						if (!drawnLines.Contains(line))
						{
							drawnLines.Add(line);

							g.DrawLine(mouseConnectionsPen, p1.ToPoint(), p2.ToPoint());

							if (chkDrawConnectorLineLengths.Checked)
								g.DrawString(Math.Round(line.Length, 1).ToString(), smallTextFont, grayBrush, new PointF(Convert.ToInt32(line.MidPoint.X) + 4, Convert.ToInt32(line.MidPoint.Y) + 4));
						}
					}
				}
			}

			if (result != null)
			{
				// Draw node values
				if (chkDrawNodeValues.Checked)
				{
					double totalDist = 0;
					Point2D previous = mouse;

					foreach (Point2D p in result)
					{
						totalDist += previous.DistanceTo(p);

						g.DrawString(Math.Round(totalDist, 1).ToString(), textFont, blackBrush, new PointF(Convert.ToInt32(p.X), Convert.ToInt32(p.Y)));

						previous = p;
					}
				}

				// Draw shortest path
				if (chkDrawShortestPath.Checked)
				{
					Point2D currentNode = mouse;
					for (int i = 0; i < result.Count - 1; i++)
						g.DrawLine(bluePen, result[i].ToPoint(), result[i + 1].ToPoint());
				}
			}

			// Update image
			pb.Image = bmp;
		}

		// Kinda deep copies a dictionary
		private Dictionary<Point2D, List<Point2D>> copyConnections(Dictionary<Point2D, List<Point2D>> source)
		{
			Dictionary<Point2D, List<Point2D>> result = new Dictionary<Point2D, List<Point2D>>();

			foreach(Point2D p1 in source.Keys)
			{
				result.Add(p1, new List<Point2D>());

				foreach (Point2D p2 in source[p1])
					result[p1].Add(p2);
			}

			return result;
		}

		private void pb_MouseMove(object sender, MouseEventArgs e)
		{
			draw(new Point2D(e.X, e.Y), targetPoint);
		}

		private bool pointIsInPolygons(Point2D point)
		{
			foreach (Polygon2D poly in polygons)
				if (poly.ContainsPoint(point.ToPoint()))
					return true;

			return false;
		}

		private void updateBaseBitmap()
		{
			Bitmap bmp = new Bitmap(pb.Width, pb.Height);
			using (Graphics g = Graphics.FromImage(bmp))
			{
				// Draw background
				g.FillRectangle(beigeBrush, new Rectangle(0, 0, pb.Width, pb.Height));

				// Draw polygons
				polygons.ForEach(p => drawPolygon(p, g));

				// Draw (unique) connections
				if (chkDrawConnectorLines.Checked)
				{
					List<Line2D> drawnLines = new List<Line2D>();
					foreach (Point2D p1 in fixedConnections.Keys)
					{
						foreach (Point2D p2 in fixedConnections[p1])
						{
							Line2D line = new Line2D(p1, p2);

							if (!drawnLines.Contains(line))
							{
								drawnLines.Add(line);

								g.DrawLine(grayPen, p1.ToPoint(), p2.ToPoint());

								if (chkDrawConnectorLineLengths.Checked)
									g.DrawString(Math.Round(line.Length, 1).ToString(), smallTextFont, grayBrush, new PointF(Convert.ToInt32(line.MidPoint.X) + 4, Convert.ToInt32(line.MidPoint.Y) + 4));
							}
						}
					}
				}

				// Update image
				baseBitmap = bmp;
			}
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			// Initialize settings
			grayPen.DashStyle = DashStyle.Dash;

			// Setup world structures
			Polygon2D poly1 = new Polygon2D();
			poly1.AddPoint(new Point(125, 100));
			poly1.AddPoint(new Point(175, 100));
			poly1.AddPoint(new Point(150, 200));
			polygons.Add(poly1);

			Polygon2D poly2 = new Polygon2D();
			poly2.AddPoint(new Point(225, 50));
			poly2.AddPoint(new Point(275, 50));
			poly2.AddPoint(new Point(250, 150));
			polygons.Add(poly2);

			Polygon2D poly3 = new Polygon2D();
			poly3.AddPoint(new Point(90, 150));
			poly3.AddPoint(new Point(105, 150));
			poly3.AddPoint(new Point(105, 250));
			poly3.AddPoint(new Point(90, 250));
			polygons.Add(poly3);

			Polygon2D poly4 = new Polygon2D();
			poly4.AddPoint(new Point(293, 115));
			poly4.AddPoint(new Point(258, 196));
			poly4.AddPoint(new Point(335, 289));
			poly4.AddPoint(new Point(372, 218));
			poly4.AddPoint(new Point(321, 172));
			poly4.AddPoint(new Point(364, 111));
			poly4.AddPoint(new Point(340, 52));
			polygons.Add(poly4);

			Polygon2D poly5 = new Polygon2D();
			poly5.AddPoint(new Point(202, 185));
			poly5.AddPoint(new Point(129, 299));
			poly5.AddPoint(new Point(217, 359));
			poly5.AddPoint(new Point(277, 320));
			polygons.Add(poly5);

			// Precalculate fixed connections
			foreach (Polygon2D poly in polygons)
				foreach (Point p in poly.Points)
					fixedPoints.Add(new Point2D(p.X, p.Y));

			foreach (Point2D p1 in fixedPoints)
			{
				fixedConnections.Add(p1, new List<Point2D>());

				// p1 will never have a connection to itself, so only loop other points
				foreach (Point2D p2 in fixedPoints.Where(p => p != p1))
					if (!intersectsAnyPolygons(new Line2D(p1, p2), polygons))
						fixedConnections[p1].Add(p2);
			}

			updateBaseBitmap();
		}

		private void chkDrawConnectorLines_CheckedChanged(object sender, EventArgs e)
		{
			updateBaseBitmap();
		}

		private void chkDrawConnectorLineLengths_CheckedChanged(object sender, EventArgs e)
		{
			updateBaseBitmap();
		}

		private void chkDrawNodeValues_CheckedChanged(object sender, EventArgs e)
		{
			updateBaseBitmap();
		}

		private void pb_MouseClick(object sender, MouseEventArgs e)
		{
			switch (e.Button)
			{
				case MouseButtons.Left:
					if (txtLog.Text.Length > 0)
						txtLog.Text += Environment.NewLine;

					txtLog.Text += "poly.AddPoint(new Point(" + e.X + ", " + e.Y + "));";
					break;

				case MouseButtons.Right:
					targetPoint = new Point2D(e.X, e.Y);
					break;
			}
		}
	}
}