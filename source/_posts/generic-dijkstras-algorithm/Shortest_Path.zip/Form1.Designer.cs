namespace Shortest_Path
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		public Form1()
		{
			InitializeComponent();
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pb = new System.Windows.Forms.PictureBox();
			this.chkDrawNodeValues = new System.Windows.Forms.CheckBox();
			this.chkDrawShortestPath = new System.Windows.Forms.CheckBox();
			this.chkDrawConnectorLineLengths = new System.Windows.Forms.CheckBox();
			this.chkDrawConnectorLines = new System.Windows.Forms.CheckBox();
			this.txtLog = new System.Windows.Forms.TextBox();
			((System.ComponentModel.ISupportInitialize)(this.pb)).BeginInit();
			this.SuspendLayout();
			// 
			// pb
			// 
			this.pb.Location = new System.Drawing.Point(12, 12);
			this.pb.Name = "pb";
			this.pb.Size = new System.Drawing.Size(440, 392);
			this.pb.TabIndex = 0;
			this.pb.TabStop = false;
			this.pb.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pb_MouseMove);
			this.pb.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pb_MouseClick);
			// 
			// chkDrawNodeValues
			// 
			this.chkDrawNodeValues.AutoSize = true;
			this.chkDrawNodeValues.Checked = true;
			this.chkDrawNodeValues.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkDrawNodeValues.Location = new System.Drawing.Point(11, 411);
			this.chkDrawNodeValues.Name = "chkDrawNodeValues";
			this.chkDrawNodeValues.Size = new System.Drawing.Size(112, 17);
			this.chkDrawNodeValues.TabIndex = 2;
			this.chkDrawNodeValues.Text = "Draw node values";
			this.chkDrawNodeValues.UseVisualStyleBackColor = true;
			this.chkDrawNodeValues.CheckedChanged += new System.EventHandler(this.chkDrawNodeValues_CheckedChanged);
			// 
			// chkDrawShortestPath
			// 
			this.chkDrawShortestPath.AutoSize = true;
			this.chkDrawShortestPath.Checked = true;
			this.chkDrawShortestPath.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkDrawShortestPath.Location = new System.Drawing.Point(11, 434);
			this.chkDrawShortestPath.Name = "chkDrawShortestPath";
			this.chkDrawShortestPath.Size = new System.Drawing.Size(115, 17);
			this.chkDrawShortestPath.TabIndex = 3;
			this.chkDrawShortestPath.Text = "Draw shortest path";
			this.chkDrawShortestPath.UseVisualStyleBackColor = true;
			// 
			// chkDrawConnectorLineLengths
			// 
			this.chkDrawConnectorLineLengths.AutoSize = true;
			this.chkDrawConnectorLineLengths.Location = new System.Drawing.Point(145, 411);
			this.chkDrawConnectorLineLengths.Name = "chkDrawConnectorLineLengths";
			this.chkDrawConnectorLineLengths.Size = new System.Drawing.Size(146, 17);
			this.chkDrawConnectorLineLengths.TabIndex = 5;
			this.chkDrawConnectorLineLengths.Text = "Draw connection weights";
			this.chkDrawConnectorLineLengths.UseVisualStyleBackColor = true;
			this.chkDrawConnectorLineLengths.CheckedChanged += new System.EventHandler(this.chkDrawConnectorLineLengths_CheckedChanged);
			// 
			// chkDrawConnectorLines
			// 
			this.chkDrawConnectorLines.AutoSize = true;
			this.chkDrawConnectorLines.Location = new System.Drawing.Point(145, 434);
			this.chkDrawConnectorLines.Name = "chkDrawConnectorLines";
			this.chkDrawConnectorLines.Size = new System.Drawing.Size(112, 17);
			this.chkDrawConnectorLines.TabIndex = 6;
			this.chkDrawConnectorLines.Text = "Draw connections";
			this.chkDrawConnectorLines.UseVisualStyleBackColor = true;
			this.chkDrawConnectorLines.CheckedChanged += new System.EventHandler(this.chkDrawConnectorLines_CheckedChanged);
			// 
			// txtLog
			// 
			this.txtLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.txtLog.Location = new System.Drawing.Point(458, 12);
			this.txtLog.Multiline = true;
			this.txtLog.Name = "txtLog";
			this.txtLog.Size = new System.Drawing.Size(243, 392);
			this.txtLog.TabIndex = 7;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(713, 455);
			this.Controls.Add(this.txtLog);
			this.Controls.Add(this.chkDrawConnectorLines);
			this.Controls.Add(this.chkDrawConnectorLineLengths);
			this.Controls.Add(this.chkDrawShortestPath);
			this.Controls.Add(this.chkDrawNodeValues);
			this.Controls.Add(this.pb);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.pb)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.PictureBox pb;
		private System.Windows.Forms.CheckBox chkDrawNodeValues;
		private System.Windows.Forms.CheckBox chkDrawShortestPath;
		private System.Windows.Forms.CheckBox chkDrawConnectorLineLengths;
		private System.Windows.Forms.CheckBox chkDrawConnectorLines;
		private System.Windows.Forms.TextBox txtLog;
	}
}