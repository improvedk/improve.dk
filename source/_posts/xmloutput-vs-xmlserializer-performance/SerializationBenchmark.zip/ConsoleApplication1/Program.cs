﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace ConsoleApplication1
{
	class Program
	{
		static void Main(string[] args)
		{
			int iterations = 100000;
			double testIterations = 10;
			double iterationTime = 0;
			Stopwatch sw = new Stopwatch();

			sw.Reset();
			iterationTime = 0;
			for (int testIteration = 0; testIteration < testIterations; testIteration++)
			{
				sw.Start();
				for (int i = 0; i < iterations; i++)
				{
					XmlOutput xo = new XmlOutput()
						.XmlDeclaration()
						.Node("root").Within()
							.Node("user").Within()
								.Node("username").InnerText("orca")
								.Node("realname").InnerText("Mark S. Rasmussen")
								.Node("description").InnerText("I'll handle any escaping (like < & > for example) needs automagically.")
								.Node("articles").Within()
									.Node("article").Attribute("id", "25").InnerText("Handling DBNulls")
									.Node("article").Attribute("id", "26").InnerText("Accessing my privates")
									.EndWithin()
								.Node("hobbies").Within()
									.Node("hobby").InnerText("Fishing")
									.Node("hobby").InnerText("Photography")
									.Node("hobby").InnerText("Work");

					string output = xo.GetOuterXml();
				}
				sw.Stop();
				iterationTime += sw.ElapsedMilliseconds;
				Console.WriteLine(sw.ElapsedMilliseconds);

				sw.Reset();
			}
			Console.WriteLine("Total XmlOutput: " + iterationTime / testIterations);



			sw.Reset();
			iterationTime = 0;
			for (int testIteration = 0; testIteration < testIterations; testIteration++)
			{
				sw.Start();
				for (int i = 0; i < iterations; i++)
				{
					User user = new User();
					user.Username = "orca";
					user.Realname = "Mark S. Rasmussen";
					user.Description = "I'll handle any escaping (like < & > for example) needs automagically.";

					user.Articles = new List<Article>();
					user.Articles.Add(new Article() { ID = 25, Content = "Handling DBNulls" });
					user.Articles.Add(new Article() { ID = 26, Content = "Accessing my privates" });

					user.Hobbies = new List<Hobby>();
					user.Hobbies.Add(new Hobby() { Content = "Fishing" });
					user.Hobbies.Add(new Hobby() { Content = "Photography" });
					user.Hobbies.Add(new Hobby() { Content = "Work" });

					string output = ConvertToXml(user);
				}
				sw.Stop();
				iterationTime += sw.ElapsedMilliseconds;
				Console.WriteLine(sw.ElapsedMilliseconds);

				sw.Reset();
			}
			Console.WriteLine("Total XmlSerializer: " + iterationTime / testIterations);



			sw.Reset();
			iterationTime = 0;
			for (int testIteration = 0; testIteration < testIterations; testIteration++)
			{
				sw.Start();
				for (int i = 0; i < iterations; i++)
				{
					User user = new User();
					user.Username = "orca";
					user.Realname = "Mark S. Rasmussen";
					user.Description = "I'll handle any escaping (like < & > for example) needs automagically.";

					user.Articles = new List<Article>();
					user.Articles.Add(new Article() { ID = 25, Content = "Handling DBNulls" });
					user.Articles.Add(new Article() { ID = 26, Content = "Accessing my privates" });

					user.Hobbies = new List<Hobby>();
					user.Hobbies.Add(new Hobby() { Content = "Fishing" });
					user.Hobbies.Add(new Hobby() { Content = "Photography" });
					user.Hobbies.Add(new Hobby() { Content = "Work" });

					string output = ConvertToXml(user);

					if(i == 0)
					{
						sw.Reset();
						sw.Start();
					}
				}
				sw.Stop();
				iterationTime += sw.ElapsedMilliseconds;
				Console.WriteLine(sw.ElapsedMilliseconds);

				sw.Reset();
			}
			Console.WriteLine("Total XmlSerializer ex 1st.: " + iterationTime / testIterations);



			Console.Read();
		}

		public static string ConvertToXml(object item)
		{
			XmlSerializer xmlser = new XmlSerializer(item.GetType());
			
			using (MemoryStream ms = new MemoryStream())
			{
				xmlser.Serialize(ms, item);
				UTF8Encoding textconverter = new UTF8Encoding();
				return textconverter.GetString(ms.ToArray());
			}
		}
	}

	public class User
	{
		public string Username;
		public string Realname;
		public string Description;
		public List<Article> Articles;
		public List<Hobby> Hobbies;
	}

	public class Article
	{
		[XmlAttribute]
		public int ID;

		[XmlText]
		public string Content;
	}

	public class Hobby
	{
		[XmlText]
		public string Content;
	}
}