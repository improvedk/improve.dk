using System;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;

public class DB
{
	public static void Debug(object o)
	{
		HttpContext.Current.Response.Write(o);
		HttpContext.Current.Response.End();
	}

	/// <summary>
	/// Returns an MSSQL representation of a boolean (1/0)
	/// </summary>
	/// <param name="boolValue"></param>
	/// <returns></returns>
	public static string ConvertToSQLBool(object boolValue)
	{
		if (Convert.ToBoolean(boolValue))
			return "1";
		else
			return "0";
	}

	public static SqlCommand GetCMD(string sql)
	{
		SqlCommand cmd = new SqlCommand(sql);

		cmd.Connection = MakeConnection();

		return cmd;
	}

	public static int GetScalarInt(SqlCommand cmd)
	{
		try
		{
			cmd.Connection = MakeConnection();
			cmd.Connection.Open();
			return Convert.ToInt32(cmd.ExecuteScalar());
		}
		catch (Exception e)
		{
			throw new Exception(cmd.CommandText, e);
		}
		finally
		{
			if (cmd.Connection.State == ConnectionState.Open)
				cmd.Connection.Close();
		}
	}

	/// <summary>
	/// Overload of the GetScalarValue function
	/// </summary>
	/// <param name="sql"></param>
	/// <returns></returns>
	public static object GetScalarValue(string sql)
	{
		return GetScalarValue(sql, MakeConnection());
	}

	/// <summary>
	/// Overload of the GetScalarValue function
	/// </summary>
	/// <param name="sql"></param>
	/// <returns></returns>
	public static string GetScalarString(string sql)
	{
		return GetScalarValue(sql).ToString();
	}

	public static int GetScalarInt(string sql)
	{
		return Convert.ToInt32(GetScalarValue(sql));
	}

	public static bool GetScalarBool(string sql)
	{
		return Convert.ToBoolean(GetScalarValue(sql));
	}

	/// <summary>
	/// Returns an object as returned by the ExecuteScalar(sql) function
	/// </summary>
	/// <param name="sql"></param>
	/// <param name="conn"></param>
	/// <returns></returns>
	public static object GetScalarValue(string sql, SqlConnection conn)
	{
		object result;

		SqlCommand sqlCmd = new SqlCommand(sql, conn);

		try
		{
			conn.Open();
			result = sqlCmd.ExecuteScalar();
		}
		catch (Exception e)
		{
			throw new Exception(sql, e);
		}
		finally
		{
			if (conn.State == ConnectionState.Open)
				conn.Close();
		}

		return result;
	}

	public static object GetScalar(SqlCommand cmd)
	{
		object result = null;
		cmd.Connection = MakeConnection();

		try
		{
			cmd.Connection.Open();
			result = cmd.ExecuteScalar();
		}
		catch
		{
			if (cmd.Connection.State == ConnectionState.Open)
				cmd.Connection.Close();
		}

		return result;
	}

	/// <summary>
	/// Overload of the GetDataTable function
	/// </summary>
	/// <param name="sql"></param>
	/// <returns></returns>
	public static DataTable GetDT(string sql)
	{
		return GetDT(sql, MakeConnection());
	}

	/// <summary>
	/// Returns a datatable with the result of the sql query
	/// </summary>
	/// <param name="sql"></param>
	/// <param name="conn"></param>
	/// <returns></returns>
	public static DataTable GetDT(string sql, SqlConnection conn)
	{
		DataTable result = new DataTable("result");
		SqlDataAdapter sqldaTemp = new SqlDataAdapter(sql, conn);

		try
		{
			conn.Open();
			sqldaTemp.Fill(result);
		}
		catch (Exception e)
		{
			throw new Exception(sql, e);
		}
		finally
		{
			if (conn.State == ConnectionState.Open)
				conn.Close();
		}

		return result;
	}

	/// <summary>
	/// Overload of the ExecuteNonQuery function
	/// </summary>
	/// <param name="sql"></param>
	public static void ExecuteNonQuery(string sql)
	{
		ExecuteNonQuery(sql, MakeConnection());
	}

	/// <summary>
	/// Executes the provided SQL
	/// </summary>
	/// <param name="sql"></param>
	/// <param name="conn"></param>
	public static void ExecuteNonQuery(string sql, SqlConnection conn)
	{
		SqlCommand sqlCmd = new SqlCommand(sql, conn);

		try
		{
			conn.Open();
			sqlCmd.ExecuteNonQuery();
		}
		catch (Exception e)
		{
			throw new Exception(sql, e);
		}
		finally
		{
			if (conn.State == ConnectionState.Open)
				conn.Close();
		}
	}

	/// <summary>
	/// Overload of the GetDataRow function
	/// </summary>
	/// <param name="sql"></param>
	/// <returns></returns>
	public static DataRow GetDR(string sql)
	{
		return GetDR(sql, MakeConnection());
	}

	/// <summary>
	/// Executes the sql parameter and returns a datarow with the data
	/// </summary>
	/// <param name="sql"></param>
	/// <param name="conn"></param>
	/// <returns></returns>
	public static DataRow GetDR(string sql, SqlConnection conn)
	{
		DataRow result;
		DataTable dtTemp = new DataTable("temp");
		SqlDataAdapter sqldaTemp = new SqlDataAdapter(sql, conn);

		try
		{
			conn.Open();
			sqldaTemp.Fill(dtTemp);

			if (dtTemp.Rows.Count > 0)
				result = dtTemp.Rows[0];
			else
				result = null;
		}
		catch (Exception e)
		{
			throw new Exception(sql, e);
		}
		finally
		{
			if (conn.State == ConnectionState.Open)
				conn.Close();
		}

		return result;
	}

	/// <summary>
	/// Returns an SqlConnection to the system db
	/// </summary>
	/// <returns>SqlConnection</returns>
	public static SqlConnection MakeConnection()
	{
		return new SqlConnection(ConfigurationManager.ConnectionStrings["Primary"].ToString());
	}
}