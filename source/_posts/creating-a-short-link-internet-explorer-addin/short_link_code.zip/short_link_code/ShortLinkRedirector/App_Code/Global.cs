using System.Web;
using System;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;

public class Global : HttpApplication
{
	private void Application_BeginRequest(object sender, EventArgs e)
	{
		string input = Request.Path.Replace("/", "");
		
		// Let's do a simple validation, the input has to be a number
		if (!Regex.IsMatch(input, @"^\d+$"))
			DB.Debug("Not a valid short link.");

		int linkID = Convert.ToInt32(input);

		// Lookup URL in database
		SqlCommand cmd = new SqlCommand("UPDATE tblShortLinks SET Visits = Visits + 1 WHERE LinkID = @LinkID; SELECT URL FROM tblShortLinks WHERE LinkID = @LinkID");
		cmd.Parameters.Add("@LinkID", SqlDbType.Int).Value = linkID;

		object url = DB.GetScalar(cmd);

		if (url != null)
			Response.Redirect(url.ToString());
		else
			DB.Debug("Link does not exist.");
	}
}