using System.Web.Services;
using System.Data.SqlClient;
using System.Data;
using System.Web;
using System;
using System.Text.RegularExpressions;

[WebService(Namespace = "http://link.improve.dk")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class ShortLinkService : WebService
{
	[WebMethod]
	public string CreateShortLinkFromURL(string url)
	{
		// We won't handle invalid URL's
		if (!Regex.IsMatch(url, @"[-\w\.]+://([-\w\.]+)+(:\d+)?(:\w+)?(@\d+)?(@\w+)?([-\w\.]+)(/([\w/_\.]*(\?\S+)?)?)?"))
			return "BAD URL";

		// Create a SqlCommand that'll lookup the URL to see if it already exists
		SqlCommand cmd = new SqlCommand("SELECT LinkID FROM tblShortLinks WHERE URL = @URL");
		cmd.Parameters.Add("@URL", SqlDbType.VarChar, 512).Value = url;

		object result = DB.GetScalar(cmd);

		// If it exists, just return the existing short link
		if (result != null)
			return "http://link.improve.dk/" + result;
		else
		{
			// Since it doesn't exist, create it and return the new link
			cmd = new SqlCommand("INSERT INTO tblShortLinks (URL, IP) VALUES (@URL, @IP); SELECT @@IDENTITY");
			cmd.Parameters.Add("@URL", SqlDbType.VarChar, 512).Value = url;
			cmd.Parameters.Add("@IP", SqlDbType.VarChar, 50).Value = HttpContext.Current.Request.UserHostAddress;

			return "http://link.improve.dk/" + Convert.ToInt32(DB.GetScalar(cmd));
		}
	}
}