using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace Improve
{
	[ComVisible(true)]
	public class ShortLinkClient
	{
		public ShortLinkClient()
		{
		}

		public string CreateShortLink(string url)
		{
			LinkService.ShortLinkService shortLinkService = new LinkService.ShortLinkService();

			return shortLinkService.CreateShortLinkFromURL(url);
		}

		public bool IsLink(string text)
		{
			return Regex.IsMatch(text, @"[-\w\.]+://([-\w\.]+)+(:\d+)?(:\w+)?(@\d+)?(@\w+)?([-\w\.]+)(/([\w/_\.]*(\?\S+)?)?)?");
		}
	}
}