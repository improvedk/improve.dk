<script>
	function main()
	{
		// Get document reference
		var doc = external.menuArguments.document;
		var range = doc.selection.createRange();
		
		// Check if any text has been selected
		if(!range.text)
		{
			alert('No text selected.');
			return;
		}
		
		// Create the ShortLinkClient object
		var shortLinkClient = new ActiveXObject('Improve.ShortLinkClient');
		
		// If link starts with www, let's add http:// for convenience
		var link = range.text.indexOf('www') == 0 ? 'http://' + range.text : range.text;
		
		// Check if selected text is actually a URL
		if(!shortLinkClient.IsLink(link))
		{
			alert('Selected text is not a valid URL.');
			return;
		}
		
		// Get a short link
		var shortLink = shortLinkClient.CreateShortLink(link);
		
		// Replace the selected text with the short link
		range.text = shortLink;
	}
	
	main();
</script>