﻿using System;
using System.Collections.Generic;
using System.Linq;
using Improve.Framework.Algorithms.Genetic;

namespace RgbGuesser
{
	class RgbGuesser : GeneticAlgorithm<Rgb>
	{
		private Random random = new Random();

		public RgbGuesser()
			: base(100, 10)
		{ }

		protected override IEnumerable<IChromosome<Rgb>> Reproduce(IEnumerable<IChromosome<Rgb>> survivors)
		{
			// Get two random chromosomes from the survivors
			var chromA = survivors
				.OrderBy(c => random.NextDouble() * c.Fitness)
				.First();

			var chromB = survivors
				.OrderBy(c => random.NextDouble() * c.Fitness)
				.Where(c => c != chromA)
				.First();

			// Now generate and return each different combination based on the two parents, with slight mutation
			var aaa = new RgbChromosome(chromA.ChromosomeValue.R, chromA.ChromosomeValue.G, chromA.ChromosomeValue.B);
			mutateChromosome(aaa);
			yield return aaa;

			var aab = new RgbChromosome(chromA.ChromosomeValue.R, chromA.ChromosomeValue.G, chromB.ChromosomeValue.B);
			mutateChromosome(aab);
			yield return aab;

			var abb = new RgbChromosome(chromA.ChromosomeValue.R, chromB.ChromosomeValue.G, chromB.ChromosomeValue.B);
			mutateChromosome(abb);
			yield return abb;

			var aba = new RgbChromosome(chromA.ChromosomeValue.R, chromB.ChromosomeValue.G, chromA.ChromosomeValue.B);
			mutateChromosome(aba);
			yield return aba;

			var baa = new RgbChromosome(chromB.ChromosomeValue.R, chromA.ChromosomeValue.G, chromA.ChromosomeValue.B);
			mutateChromosome(baa);
			yield return baa;

			var bba = new RgbChromosome(chromB.ChromosomeValue.R, chromB.ChromosomeValue.G, chromA.ChromosomeValue.B);
			mutateChromosome(bba);
			yield return bba;

			var bab = new RgbChromosome(chromB.ChromosomeValue.R, chromA.ChromosomeValue.G, chromB.ChromosomeValue.B);
			mutateChromosome(bab);
			yield return bab;

			var bbb = new RgbChromosome(chromB.ChromosomeValue.R, chromB.ChromosomeValue.G, chromB.ChromosomeValue.B);
			mutateChromosome(bbb);
			yield return bbb;
		}

		private void mutateChromosome(IChromosome<Rgb> chromosome)
		{
			chromosome.ChromosomeValue.R = Math.Min(255, Math.Max(0, chromosome.ChromosomeValue.R + random.Next(-5, 6)));
			chromosome.ChromosomeValue.G = Math.Min(255, Math.Max(0, chromosome.ChromosomeValue.G + random.Next(-5, 6)));
			chromosome.ChromosomeValue.B = Math.Min(255, Math.Max(0, chromosome.ChromosomeValue.B + random.Next(-5, 6)));
		}

		protected override IChromosome<Rgb> CreateInitialRandomChromosome()
		{
			return new RgbChromosome(random.Next(1, 256), random.Next(1, 256), random.Next(1, 256));
		}

		protected override IEnumerable<IChromosome<Rgb>> GetGenerationSurvivors()
		{
			// Return the best chromosome
			var topChromosome = this.ChromosomePopulation
				.OrderByDescending(c => c.Fitness)
				.First();

			// Return the remaining chromosomes from the pool
			var survivors = this.ChromosomePopulation
				.Where(c => c != topChromosome)
				.OrderByDescending(c => random.NextDouble() * c.Fitness)
				.Take(this.GenerationSurvivorCount - 1);

			yield return topChromosome;

			foreach (var survivor in survivors)
				yield return survivor;
		}
	}
}