﻿using System;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace AvailabilityTester
{
	public partial class Form1 : Form
	{
		public static bool Running;
		int sleepBetweenPolls = 250;
		int sqlConnectionTcpTimeout = 250;
		string principalConnection = "Data Source=Mandalay;Connect Timeout=1;Initial Catalog=AdventureWorks;User Id=sa;Password=sadpassword;Pooling=false";
		string mirrorConnection = "Data Source=Rio;Connect Timeout=1;Initial Catalog=AdventureWorks;User Id=sa;Password=sadpassword;Pooling=false";
		string totalConnection = "Data Source=Rio;Failover Partner=Mandalay;Connect Timeout=1;Initial Catalog=AdventureWorks;User Id=sa;Password=sadpassword;Pooling=false";

		public Form1()
		{
			InitializeComponent();

			Control.CheckForIllegalCrossThreadCalls = false;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (button1.Text == "Begin")
			{
				// Start
				Running = true;
				button1.Text = "End";

				Thread tPrincipal = new Thread(delegate()
				{
					while (Running)
					{
						pollServer(principalConnection, lblSumPrincipal, lblLastUpdatedPrincipal, pbPrincipal, "Principal");

						Thread.Sleep(sleepBetweenPolls);
					}
				});

				Thread tMirror = new Thread(delegate()
				{
					while (Running)
					{
						pollServer(mirrorConnection, lblSumMirror, lblLastUpdatedMirror, pbMirror, "Mirror");

						Thread.Sleep(sleepBetweenPolls);
					}
				});

				Thread tTotal = new Thread(delegate()
				{
					while (Running)
					{
						pollServer(totalConnection, lblSumTotal, lblLastUpdatedTotal, pbTotal, "Total");

						Thread.Sleep(sleepBetweenPolls);
					}
				});

				if(chkPrincipal.Checked)
					tPrincipal.Start();
				if(chkMirror.Checked)
					tMirror.Start();
				if(chkTotal.Checked)
					tTotal.Start();
			}
			else
			{
				// Stop
				Running = false;
				button1.Text = "Begin";
			}
		}

		private void pollServer(string connection, Label lblSum, Label lblLastUpdated, PictureBox pb, string type)
		{
			using (SqlConnection conn = new SqlConnection(connection))
			{
				SqlConnection.ClearAllPools();

				using (SqlCommand cmd = conn.CreateCommand())
				{
					cmd.CommandTimeout = 1;
					cmd.CommandText = "SELECT AVG(SafetyStockLevel) FROM Production.Product -- " + type;

					try
					{
						conn.QuickOpen(sqlConnectionTcpTimeout);
						object result = cmd.ExecuteScalar();
						conn.Close();

						lblSum.Text = result.ToString();
						pb.BackColor = Color.Green;
					}
					catch
					{
						conn.Close();
						lblSum.Text = "N/A";
						pb.BackColor = Color.Red;
					}

					lblLastUpdated.Text = DateTime.Now.TimeOfDay.ToString();
				}
			}

			using (SqlConnection conn = new SqlConnection(connection))
			{
				SqlConnection.ClearAllPools();

				using (SqlCommand cmd = conn.CreateCommand())
				{
					cmd.CommandTimeout = 1;
					cmd.CommandText = "UPDATE Production.Product SET SafetyStockLevel = SafetyStockLevel + 1 -- " + type;

					try
					{
						conn.QuickOpen(sqlConnectionTcpTimeout);
						cmd.ExecuteNonQuery();
						conn.Close();

						pb.BackColor = Color.Green;
					}
					catch (Exception e)
					{
						conn.Close();
						pb.BackColor = Color.Red;
					}

					lblLastUpdated.Text = DateTime.Now.TimeOfDay.ToString();
				}
			}
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			Running = false;
		}
	}

	public static class SqlExtensions
	{
		public static void QuickOpen(this SqlConnection conn, int timeout)
		{
			// We'll use a Stopwatch here for simplicity. A comparison to a stored DateTime.Now value could also be used
			Stopwatch sw = new Stopwatch();
			bool connectSuccess = false;

			// Try to open the connection, if anything goes wrong, make sure we set connectSuccess = false
			Thread t = new Thread(delegate()
			{
				try
				{
					sw.Start();
					conn.Open();
					connectSuccess = true;
				}
				catch { }
			});

			// Make sure it's marked as a background thread so it'll get cleaned up automatically
			t.IsBackground = true;
			t.Start();

			// Keep trying to join the thread until we either succeed or the timeout value has been exceeded
			while (timeout > sw.ElapsedMilliseconds)
				if (t.Join(1))
					break;

			// If we didn't connect successfully, throw an exception
			if (!connectSuccess)
				throw new Exception("Timed out while trying to connect.");
		}
	}
}