﻿namespace AvailabilityTester
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.chkPrincipal = new System.Windows.Forms.CheckBox();
			this.lblLastUpdatedPrincipal = new System.Windows.Forms.Label();
			this.lblSumPrincipal = new System.Windows.Forms.Label();
			this.pbPrincipal = new System.Windows.Forms.PictureBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.chkMirror = new System.Windows.Forms.CheckBox();
			this.lblLastUpdatedMirror = new System.Windows.Forms.Label();
			this.lblSumMirror = new System.Windows.Forms.Label();
			this.pbMirror = new System.Windows.Forms.PictureBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.chkTotal = new System.Windows.Forms.CheckBox();
			this.lblLastUpdatedTotal = new System.Windows.Forms.Label();
			this.lblSumTotal = new System.Windows.Forms.Label();
			this.pbTotal = new System.Windows.Forms.PictureBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbPrincipal)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbMirror)).BeginInit();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbTotal)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.chkPrincipal);
			this.groupBox3.Controls.Add(this.lblLastUpdatedPrincipal);
			this.groupBox3.Controls.Add(this.lblSumPrincipal);
			this.groupBox3.Controls.Add(this.pbPrincipal);
			this.groupBox3.Controls.Add(this.label5);
			this.groupBox3.Controls.Add(this.label1);
			this.groupBox3.Location = new System.Drawing.Point(12, 15);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Padding = new System.Windows.Forms.Padding(10);
			this.groupBox3.Size = new System.Drawing.Size(211, 120);
			this.groupBox3.TabIndex = 2;
			this.groupBox3.TabStop = false;
			// 
			// chkPrincipal
			// 
			this.chkPrincipal.AutoSize = true;
			this.chkPrincipal.Checked = true;
			this.chkPrincipal.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkPrincipal.Location = new System.Drawing.Point(13, 0);
			this.chkPrincipal.Name = "chkPrincipal";
			this.chkPrincipal.Size = new System.Drawing.Size(134, 17);
			this.chkPrincipal.TabIndex = 6;
			this.chkPrincipal.Text = "Principal (MANDALAY)";
			this.chkPrincipal.UseVisualStyleBackColor = true;
			// 
			// lblLastUpdatedPrincipal
			// 
			this.lblLastUpdatedPrincipal.Location = new System.Drawing.Point(91, 39);
			this.lblLastUpdatedPrincipal.Name = "lblLastUpdatedPrincipal";
			this.lblLastUpdatedPrincipal.Size = new System.Drawing.Size(107, 16);
			this.lblLastUpdatedPrincipal.TabIndex = 5;
			this.lblLastUpdatedPrincipal.Text = "0";
			this.lblLastUpdatedPrincipal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lblSumPrincipal
			// 
			this.lblSumPrincipal.Location = new System.Drawing.Point(143, 23);
			this.lblSumPrincipal.Name = "lblSumPrincipal";
			this.lblSumPrincipal.Size = new System.Drawing.Size(55, 16);
			this.lblSumPrincipal.TabIndex = 5;
			this.lblSumPrincipal.Text = "0";
			this.lblSumPrincipal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pbPrincipal
			// 
			this.pbPrincipal.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.pbPrincipal.BackColor = System.Drawing.Color.Silver;
			this.pbPrincipal.Location = new System.Drawing.Point(13, 62);
			this.pbPrincipal.Name = "pbPrincipal";
			this.pbPrincipal.Size = new System.Drawing.Size(185, 45);
			this.pbPrincipal.TabIndex = 0;
			this.pbPrincipal.TabStop = false;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(13, 41);
			this.label5.Name = "label5";
			this.label5.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
			this.label5.Size = new System.Drawing.Size(72, 18);
			this.label5.TabIndex = 4;
			this.label5.Text = "Last updated:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(13, 23);
			this.label1.Name = "label1";
			this.label1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
			this.label1.Size = new System.Drawing.Size(124, 18);
			this.label1.TabIndex = 4;
			this.label1.Text = "SUM(SafetyStockLevel):";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(12, 271);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(428, 43);
			this.button1.TabIndex = 3;
			this.button1.Text = "Begin";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.chkMirror);
			this.groupBox1.Controls.Add(this.lblLastUpdatedMirror);
			this.groupBox1.Controls.Add(this.lblSumMirror);
			this.groupBox1.Controls.Add(this.pbMirror);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Location = new System.Drawing.Point(229, 15);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new System.Windows.Forms.Padding(10);
			this.groupBox1.Size = new System.Drawing.Size(211, 120);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			// 
			// chkMirror
			// 
			this.chkMirror.AutoSize = true;
			this.chkMirror.Checked = true;
			this.chkMirror.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkMirror.Location = new System.Drawing.Point(13, 0);
			this.chkMirror.Name = "chkMirror";
			this.chkMirror.Size = new System.Drawing.Size(80, 17);
			this.chkMirror.TabIndex = 6;
			this.chkMirror.Text = "Mirror (RIO)";
			this.chkMirror.UseVisualStyleBackColor = true;
			// 
			// lblLastUpdatedMirror
			// 
			this.lblLastUpdatedMirror.Location = new System.Drawing.Point(88, 39);
			this.lblLastUpdatedMirror.Name = "lblLastUpdatedMirror";
			this.lblLastUpdatedMirror.Size = new System.Drawing.Size(110, 16);
			this.lblLastUpdatedMirror.TabIndex = 5;
			this.lblLastUpdatedMirror.Text = "0";
			this.lblLastUpdatedMirror.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lblSumMirror
			// 
			this.lblSumMirror.Location = new System.Drawing.Point(143, 20);
			this.lblSumMirror.Name = "lblSumMirror";
			this.lblSumMirror.Size = new System.Drawing.Size(55, 16);
			this.lblSumMirror.TabIndex = 5;
			this.lblSumMirror.Text = "0";
			this.lblSumMirror.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pbMirror
			// 
			this.pbMirror.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.pbMirror.BackColor = System.Drawing.Color.Silver;
			this.pbMirror.Location = new System.Drawing.Point(13, 62);
			this.pbMirror.Name = "pbMirror";
			this.pbMirror.Size = new System.Drawing.Size(185, 45);
			this.pbMirror.TabIndex = 0;
			this.pbMirror.TabStop = false;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(10, 41);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(72, 13);
			this.label6.TabIndex = 4;
			this.label6.Text = "Last updated:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(13, 23);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(124, 13);
			this.label2.TabIndex = 4;
			this.label2.Text = "SUM(SafetyStockLevel):";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.chkTotal);
			this.groupBox2.Controls.Add(this.lblLastUpdatedTotal);
			this.groupBox2.Controls.Add(this.lblSumTotal);
			this.groupBox2.Controls.Add(this.pbTotal);
			this.groupBox2.Controls.Add(this.label4);
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Location = new System.Drawing.Point(12, 141);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Padding = new System.Windows.Forms.Padding(10);
			this.groupBox2.Size = new System.Drawing.Size(428, 124);
			this.groupBox2.TabIndex = 4;
			this.groupBox2.TabStop = false;
			// 
			// chkTotal
			// 
			this.chkTotal.AutoSize = true;
			this.chkTotal.Checked = true;
			this.chkTotal.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkTotal.Location = new System.Drawing.Point(13, 0);
			this.chkTotal.Name = "chkTotal";
			this.chkTotal.Size = new System.Drawing.Size(120, 17);
			this.chkTotal.TabIndex = 6;
			this.chkTotal.Text = "Mirrored conncetion";
			this.chkTotal.UseVisualStyleBackColor = true;
			// 
			// lblLastUpdatedTotal
			// 
			this.lblLastUpdatedTotal.Location = new System.Drawing.Point(268, 39);
			this.lblLastUpdatedTotal.Name = "lblLastUpdatedTotal";
			this.lblLastUpdatedTotal.Size = new System.Drawing.Size(147, 16);
			this.lblLastUpdatedTotal.TabIndex = 5;
			this.lblLastUpdatedTotal.Text = "0";
			this.lblLastUpdatedTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lblSumTotal
			// 
			this.lblSumTotal.Location = new System.Drawing.Point(360, 20);
			this.lblSumTotal.Name = "lblSumTotal";
			this.lblSumTotal.Size = new System.Drawing.Size(55, 16);
			this.lblSumTotal.TabIndex = 5;
			this.lblSumTotal.Text = "0";
			this.lblSumTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// pbTotal
			// 
			this.pbTotal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.pbTotal.BackColor = System.Drawing.Color.Silver;
			this.pbTotal.Location = new System.Drawing.Point(13, 63);
			this.pbTotal.Name = "pbTotal";
			this.pbTotal.Size = new System.Drawing.Size(402, 48);
			this.pbTotal.TabIndex = 0;
			this.pbTotal.TabStop = false;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(10, 41);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(72, 13);
			this.label4.TabIndex = 4;
			this.label4.Text = "Last updated:";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(10, 23);
			this.label3.Name = "label3";
			this.label3.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
			this.label3.Size = new System.Drawing.Size(124, 18);
			this.label3.TabIndex = 4;
			this.label3.Text = "SUM(SafetyStockLevel):";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(452, 324);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.groupBox3);
			this.Name = "Form1";
			this.Text = "Availability Tester";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbPrincipal)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbMirror)).EndInit();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pbTotal)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.PictureBox pbPrincipal;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.PictureBox pbMirror;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.PictureBox pbTotal;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label lblSumPrincipal;
		private System.Windows.Forms.Label lblSumMirror;
		private System.Windows.Forms.Label lblSumTotal;
		private System.Windows.Forms.Label lblLastUpdatedTotal;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label lblLastUpdatedPrincipal;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label lblLastUpdatedMirror;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.CheckBox chkPrincipal;
		private System.Windows.Forms.CheckBox chkMirror;
		private System.Windows.Forms.CheckBox chkTotal;
	}
}

