﻿using System;
using System.IO;
using System.Security;
using System.Security.Permissions;

namespace Demo10___StackwalkPitfall
{
	class Program
	{
		[FileIOPermission(SecurityAction.Deny, Unrestricted = true)]
		static void Main(string[] args)
		{
			try
			{
				using(UnknownClass uc = new UnknownClass())
				{
					var fop = new FileIOPermission(PermissionState.Unrestricted);
					fop.Assert();

					uc.DoSomething();

					CodeAccessPermission.RevertAll();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex);
			}
			finally
			{
				Console.ReadKey();
			}
		}
	}

	class UnknownClass : IDisposable
	{
		public void DoSomething()
		{
			Console.WriteLine("I'm innocent");
			throw new Exception();
		}

		public void Dispose()
		{
			Console.WriteLine("Secret file contents: " + File.ReadAllText(@"C:\secretfile.html"));
		}
	}
}