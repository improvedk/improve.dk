﻿using System;
using System.IO;
using System.Security.Permissions;

[assembly:FileIOPermission(SecurityAction.RequestMinimum, Unrestricted = true)]

namespace Demo4___Request
{
	class Program
	{
		static void Main(string[] args)
		{
			File.WriteAllText(@"C:\request.txt", "Requesting world!");

			Console.WriteLine("Done");
			Console.ReadKey();
		}
	}
}