﻿using System;
using System.Security;
using System.Security.Permissions;

namespace Demo3___Demand
{
	class Program
	{
		[FileIOPermission(SecurityAction.Deny, Unrestricted = true)]
		static void Main(string[] args)
		{
			try
			{
				readFile();
			}
			catch (SecurityException ex) { Console.WriteLine(ex); }
			finally { Console.ReadKey(); }
		}

		static void readFile()
		{
			actuallyAlmostReadFile();
		}

		//[FileIOPermission(SecurityAction.Demand, Read=@"C:\")]
		[FileIOPermission(SecurityAction.LinkDemand, Read=@"C:\")]
		static void actuallyAlmostReadFile()
		{
			//var iop = new FileIOPermission(FileIOPermissionAccess.Read, @"C:\test.txt");
			//iop.Demand();

			Console.WriteLine("Let's pretend I just read a file");
		}
	}
}