﻿using System;
using System.Security;
using System.Security.Permissions;
using System.IO;

namespace Demo7___Assert
{
	class Program
	{
		[FileIOPermission(SecurityAction.Deny, Unrestricted = true)]
		static void Main(string[] args)
		{
			try
			{
				readFile();
			}
			catch (SecurityException ex)
			{
				Console.WriteLine(ex);
			}
			finally
			{
				Console.ReadKey();
			}
		}

		static void readFile()
		{
			var fop = new FileIOPermission(FileIOPermissionAccess.Read, @"C:\");
			fop.Assert();

			actuallyAlmostReadFile();
		}

		[FileIOPermission(SecurityAction.Demand, Read=@"C:\")]
		static void actuallyAlmostReadFile()
		{
			Console.WriteLine("Let's pretend I just read a file");
		}
	}
}