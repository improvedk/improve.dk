﻿using System;
using System.IO;

namespace FileWrite
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Action:");

			switch (Console.ReadKey(true).KeyChar)
			{
				case 'r':
					Console.WriteLine("Read file: " + File.ReadAllText(@"C:\test.txt"));
					break;

				case 'w':
					File.WriteAllText(@"C:\test.txt", "Hello world! " + DateTime.Now);
					Console.WriteLine("Wrote file");
					break;
			}

			Console.WriteLine("Done");
			Console.ReadKey();
		}
	}
}