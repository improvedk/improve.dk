/*
	Reset
*/
USE master
IF(EXISTS(SELECT * FROM sys.databases WHERE name = 'MOWGUID')) BEGIN
	ALTER DATABASE MOWGUID SET SINGLE_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE MOWGUID	
END
CREATE DATABASE MOWGUID
GO
USE MOWGUID
SET STATISTICS IO ON



-- Create table
CREATE TABLE GuidPersons
(
	ID UNIQUEIDENTIFIER DEFAULT(NEWID()) NOT NULL,
	Age INT NOT NULL,
	Name NVARCHAR(128) NOT NULL,
	Email NVARCHAR(128) NOT NULL,
	SomeData CHAR(500) NOT NULL
)
ALTER TABLE GuidPersons ADD CONSTRAINT PK_tblGuids_ID PRIMARY KEY CLUSTERED (ID)



-- Insert data
INSERT INTO GuidPersons (Age, Name, Email, SomeData)
SELECT TOP 50000 Age, Name, Email, '' FROM Data.dbo.Persons
GO 2



-- Check space
SELECT
	'GuidPersons',
	index_type_desc,
	avg_fragmentation_in_percent,
	fragment_count,
	avg_fragment_size_in_pages,
	page_count * 8192 / 1024 AS space_in_kb,
	avg_page_space_used_in_percent,
	avg_record_size_in_bytes
FROM
	sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('GuidPersons'), NULL, NULL, 'DETAILED')
WHERE
	index_level = 0
	


-- Maintenance repercussions
ALTER INDEX PK_tblGuids_ID ON GuidPersons REBUILD WITH (FILLFACTOR = 80)



-- Check space
SELECT
	'GuidPersons',
	index_type_desc,
	avg_fragmentation_in_percent,
	fragment_count,
	avg_fragment_size_in_pages,
	page_count * 8192 / 1024 AS space_in_kb,
	avg_page_space_used_in_percent,
	avg_record_size_in_bytes
FROM
	sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('GuidPersons'), NULL, NULL, 'DETAILED')
WHERE
	index_level = 0
	


-- Insert data
INSERT INTO GuidPersons (Age, Name, Email, SomeData)
SELECT TOP 50000 Age, Name, Email, '' FROM Data.dbo.Persons



-- Check space
SELECT
	'GuidPersons',
	index_type_desc,
	avg_fragmentation_in_percent,
	fragment_count,
	avg_fragment_size_in_pages,
	page_count * 8192 / 1024 AS space_in_kb,
	avg_page_space_used_in_percent,
	avg_record_size_in_bytes
FROM
	sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('GuidPersons'), NULL, NULL, 'DETAILED')
WHERE
	index_level = 0
	
	
	
-- Maintenance repercussions
ALTER INDEX PK_tblGuids_ID ON GuidPersons REBUILD WITH (FILLFACTOR = 50)



-- Check space
SELECT
	'GuidPersons',
	index_type_desc,
	avg_fragmentation_in_percent,
	fragment_count,
	avg_fragment_size_in_pages,
	page_count * 8192 / 1024 AS space_in_kb,
	avg_page_space_used_in_percent,
	avg_record_size_in_bytes
FROM
	sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('GuidPersons'), NULL, NULL, 'DETAILED')
WHERE
	index_level = 0
	


-- Insert data
INSERT INTO GuidPersons (Age, Name, Email, SomeData)
SELECT TOP 50000 Age, Name, Email, '' FROM Data.dbo.Persons



-- Check space
SELECT
	'GuidPersons',
	index_type_desc,
	avg_fragmentation_in_percent,
	fragment_count,
	avg_fragment_size_in_pages,
	page_count * 8192 / 1024 AS space_in_kb,
	avg_page_space_used_in_percent,
	avg_record_size_in_bytes
FROM
	sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('GuidPersons'), NULL, NULL, 'DETAILED')
WHERE
	index_level = 0