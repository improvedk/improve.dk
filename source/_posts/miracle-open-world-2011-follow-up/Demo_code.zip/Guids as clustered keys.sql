/*
	Reset
*/
USE master
IF(EXISTS(SELECT * FROM sys.databases WHERE name = 'MOWGUID')) BEGIN
	ALTER DATABASE MOWGUID SET SINGLE_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE MOWGUID	
END
CREATE DATABASE MOWGUID
GO
USE MOWGUID
SET STATISTICS IO ON



-- Create tables
CREATE TABLE GuidPersons
(
	ID UNIQUEIDENTIFIER DEFAULT(NEWID()) NOT NULL,
	Age INT NOT NULL,
	Name NVARCHAR(128) NOT NULL,
	Email NVARCHAR(128) NOT NULL,
	SomeData CHAR(500) NOT NULL
)
ALTER TABLE GuidPersons ADD CONSTRAINT PK_tblGuids_ID PRIMARY KEY CLUSTERED (ID)
CREATE NONCLUSTERED INDEX NC_Email ON GuidPersons (Email ASC)
CREATE NONCLUSTERED INDEX NC_Name ON GuidPersons (Name ASC)

CREATE TABLE IntPersons
(
	ID INT IDENTITY(1,1) NOT NULL,
	Age INT NOT NULL,
	Name NVARCHAR(128) NOT NULL,
	Email NVARCHAR(128) NOT NULL,
	SomeData CHAR(500) NOT NULL
)
ALTER TABLE IntPersons ADD CONSTRAINT PK_tblInts_ID PRIMARY KEY CLUSTERED (ID)
CREATE NONCLUSTERED INDEX NC_Email ON IntPersons (Email ASC)
CREATE NONCLUSTERED INDEX NC_Name ON IntPersons (Name ASC)
GO



-- Insert data
INSERT INTO IntPersons (Age, Name, Email, SomeData)
SELECT TOP 50000 Age, Name, Email, '' FROM Data.dbo.Persons

INSERT INTO GuidPersons (Age, Name, Email, SomeData)
SELECT TOP 50000 Age, Name, Email, '' FROM Data.dbo.Persons
GO 4



-- Check space
SELECT
	'IntPersons',
	index_type_desc,
	avg_fragmentation_in_percent,
	fragment_count,
	avg_fragment_size_in_pages,
	page_count * 8192 / 1024 AS space_in_kb,
	avg_page_space_used_in_percent,
	avg_record_size_in_bytes
FROM
	sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('IntPersons'), NULL, NULL, 'DETAILED')
WHERE
	index_level = 0

UNION ALL

SELECT
	'GuidPersons',
	index_type_desc,
	avg_fragmentation_in_percent,
	fragment_count,
	avg_fragment_size_in_pages,
	page_count * 8192 / 1024 AS space_in_kb,
	avg_page_space_used_in_percent,
	avg_record_size_in_bytes
FROM
	sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('GuidPersons'), NULL, NULL, 'DETAILED')
WHERE
	index_level = 0
	
	

-- Select IO repercussions
SELECT ID FROM IntPersons
SELECT ID FROM GuidPersons

SELECT ID, Age FROM IntPersons
SELECT ID, Age FROM GuidPersons



-- Maintenance repercussions
SELECT 'IntPersons', index_type_desc, avg_fragmentation_in_percent, fragment_count, avg_fragment_size_in_pages, page_count * 8192 / 1024 AS space_in_kb, avg_page_space_used_in_percent, avg_record_size_in_bytes FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('IntPersons'), NULL, NULL, 'DETAILED') WHERE index_level = 0
UNION ALL
SELECT 'GuidPersons', index_type_desc, avg_fragmentation_in_percent, fragment_count, avg_fragment_size_in_pages, page_count * 8192 / 1024 AS space_in_kb, avg_page_space_used_in_percent, avg_record_size_in_bytes FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('GuidPersons'), NULL, NULL, 'DETAILED') WHERE index_level = 0

ALTER INDEX NC_Name ON IntPersons REBUILD
ALTER INDEX NC_Email ON IntPersons REBUILD

ALTER INDEX PK_tblGuids_ID ON GuidPersons REBUILD
ALTER INDEX NC_Name ON GuidPersons REBUILD
ALTER INDEX NC_Email ON GuidPersons REBUILD

SELECT 'IntPersons', index_type_desc, avg_fragmentation_in_percent, fragment_count, avg_fragment_size_in_pages, page_count * 8192 / 1024 AS space_in_kb, avg_page_space_used_in_percent, avg_record_size_in_bytes FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('IntPersons'), NULL, NULL, 'DETAILED') WHERE index_level = 0
UNION ALL
SELECT 'GuidPersons', index_type_desc, avg_fragmentation_in_percent, fragment_count, avg_fragment_size_in_pages, page_count * 8192 / 1024 AS space_in_kb, avg_page_space_used_in_percent, avg_record_size_in_bytes FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('GuidPersons'), NULL, NULL, 'DETAILED') WHERE index_level = 0



-- Select IO repercussions
SELECT ID FROM IntPersons
SELECT ID FROM GuidPersons

SELECT ID, Age FROM IntPersons
SELECT ID, Age FROM GuidPersons