﻿using System;
using System.Linq;
using Microsoft.Web.Administration;

namespace PrintRequests
{
	class Program
	{
		static void Main(string[] args)
		{
			ServerManager iisManager = new ServerManager();

			foreach (WorkerProcess w3wp in iisManager.WorkerProcesses)
			{
				Console.WriteLine("W3WP ({0})", w3wp.ProcessId);

				foreach (Request request in w3wp.GetRequests(0).Where(req => req.Url == "/default.aspx"))
				{
					Console.WriteLine("URL: " + request.Url);
					Console.WriteLine("TimeElapsed: " + request.TimeElapsed);
					Console.WriteLine("TimeInState: " + request.TimeInState);
					Console.WriteLine("TimeInModule: " + request.TimeInModule);
					Console.WriteLine("CurrentModule: " + request.CurrentModule);
					Console.WriteLine("PipelineState: " + request.PipelineState);
					Console.WriteLine();
				}
			}

			Console.Read();
		}
	}
}