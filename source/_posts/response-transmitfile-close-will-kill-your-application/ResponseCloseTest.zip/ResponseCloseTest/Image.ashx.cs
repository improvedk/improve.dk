﻿using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Diagnostics;

namespace ResponseCloseTest
{
	public class Image : IHttpHandler
	{
		public void ProcessRequest(HttpContext context)
		{
			context.Response.Buffer = false;
			context.Response.TransmitFile("Tree.jpg");
			context.Response.Close();
			Thread.Sleep(2000);
		}

		public bool IsReusable
		{
			get
			{
				return false;
			}
		}
	}
}