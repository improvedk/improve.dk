﻿using System;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Web;

namespace ResponseCloseTest
{
	public partial class _Default : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			Response.Buffer = false;
			Response.TransmitFile("Tree.jpg");
			Response.Close();
			Thread.Sleep(2000);
		}
		
		/*
		protected void Page_Load(object sender, EventArgs e)
		{
			Response.WriteFile("Tree.jpg");
			Response.Flush();
			Response.Close();
			Thread.Sleep(2000);
		}
		
		protected void Page_Load(object sender, EventArgs e)
		{
			Response.BinaryWrite(File.ReadAllBytes(Server.MapPath("Tree.jpg")));
			Response.Flush();
			Response.Close();
			Thread.Sleep(2000);
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			int chunkSize = 64;
			byte[] buffer = new byte[chunkSize];
			int offset = 0;
			int read = 0;
			using (FileStream fs = File.Open(Server.MapPath("Tree.jpg"), FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				while ((read = fs.Read(buffer, offset, chunkSize)) > 0)
					Response.OutputStream.Write(buffer, 0, read);
			}
			
			Response.Flush();
			Response.Close();
			Thread.Sleep(2000);
		}
		*/
	}
}