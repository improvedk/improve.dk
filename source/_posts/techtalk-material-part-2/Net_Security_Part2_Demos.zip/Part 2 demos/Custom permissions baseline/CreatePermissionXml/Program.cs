﻿using System;
using System.IO;
using BeepPermissionNamespace;

namespace CreatePermissionSet
{
	class Program
	{
		static void Main(string[] args)
		{
			var perm = new BeepPermission(5);

			using(var sw = new StreamWriter("beepPermission.xml"))
				sw.Write(perm.ToXml());

			Console.Write("Done");
			Console.Read();
		}
	}
}