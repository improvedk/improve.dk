﻿using System.Runtime.InteropServices;
using System.Threading;

namespace BeepGateway
{
	public sealed class NativeFunctions
	{
		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool MessageBeep(int type);

		public static void Beep(int beepCount)
		{
			for (int i = 0; i < beepCount; i++)
			{
				MessageBeep(-1);

				Thread.Sleep(500);
			}
		}
	}
}