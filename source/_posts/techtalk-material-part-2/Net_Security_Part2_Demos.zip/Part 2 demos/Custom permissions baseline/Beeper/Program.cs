﻿using System;
using System.Runtime.InteropServices;

namespace Beeper
{
	class Program
	{
		[DllImport("user32.dll", SetLastError = true)]
		public static extern bool MessageBeep(int type);

		static void Main(string[] args)
		{
			MessageBeep(-1);

			Console.Write("Done");
			Console.Read();
		}
	}
}