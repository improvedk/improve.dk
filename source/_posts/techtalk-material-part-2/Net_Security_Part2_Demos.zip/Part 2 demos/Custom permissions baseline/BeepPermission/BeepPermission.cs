﻿using System;
using System.Security;
using System.Security.Permissions;

namespace BeepPermissionNamespace
{
	public sealed class BeepPermission : CodeAccessPermission, IPermission, IUnrestrictedPermission
	{
		private int beepAllowance;

		public BeepPermission(int beepAllowance)
		{
			this.beepAllowance = beepAllowance;
		}

		public override SecurityElement ToXml()
		{
			SecurityElement se = new SecurityElement("IPermission");
			se.AddAttribute("class", this.GetType().AssemblyQualifiedName.Replace("\"", "'"));
			se.AddAttribute("version", "1");
			se.AddAttribute("beepAllowance", beepAllowance.ToString());

			return se;
		}

		public override void FromXml(SecurityElement e)
		{
			string xmlAllowance = (string)e.Attributes["beepAllowance"];

			if (xmlAllowance != null)
				beepAllowance = Convert.ToInt32(xmlAllowance);
		}

		public override IPermission Union(IPermission target)
		{
			if (target.GetType() != this.GetType())
				throw new ArgumentException("Target type must be of type BeepPermission");

			if (target == null)
				return Copy();

			BeepPermission perm = (BeepPermission)target;

			return new BeepPermission(Math.Max(beepAllowance, perm.beepAllowance));
		}

		public override IPermission Copy()
		{
			return new BeepPermission(beepAllowance);
		}

		public override bool IsSubsetOf(IPermission target)
		{
			if (target == null)
				return false;

			if (target.GetType() != this.GetType())
				throw new ArgumentException("Target type must be of type BeepPermission");

			BeepPermission perm = (BeepPermission)target;

			return beepAllowance <= perm.beepAllowance;
		}

		public override IPermission Intersect(IPermission target)
		{
			if (target == null)
				return null;

			if (target.GetType() != this.GetType())
				throw new ArgumentException("Target type must be of type BeepPermission");

			BeepPermission perm = (BeepPermission)target;

			return new BeepPermission(Math.Min(beepAllowance, perm.beepAllowance));
		}

		public bool IsUnrestricted()
		{
			// We'll always be unrestricted
			return beepAllowance == int.MaxValue;
		}
	}
}