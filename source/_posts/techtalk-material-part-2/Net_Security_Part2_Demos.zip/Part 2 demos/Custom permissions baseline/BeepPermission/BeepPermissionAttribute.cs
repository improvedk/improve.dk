﻿using System;
using System.Security;
using System.Security.Permissions;

namespace BeepPermissionNamespace
{
	[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
	public class BeepPermissionAttribute : CodeAccessSecurityAttribute
	{
		public BeepPermissionAttribute(SecurityAction action) : base(action)
		{ }

		public int AllowedBeeps { get; set; }

		public override IPermission CreatePermission()
		{
			if (Unrestricted)
				return new BeepPermission(int.MaxValue);
			else
				return new BeepPermission(AllowedBeeps);
		}
	}
}