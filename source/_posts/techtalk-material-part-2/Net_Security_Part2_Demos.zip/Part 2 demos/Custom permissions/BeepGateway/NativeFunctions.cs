﻿using System.Runtime.InteropServices;
using System.Threading;
using System.Security;
using BeepPermissionNamespace;
using System.Security.Permissions;

[assembly: AllowPartiallyTrustedCallers]

namespace BeepGateway
{
	public sealed class NativeFunctions
	{
		[DllImport("user32.dll", SetLastError = true), SuppressUnmanagedCodeSecurity]
		private static extern bool MessageBeep(int type);

		public static void Beep(int beepCount)
		{
			new BeepPermission(beepCount).Demand();

			for (int i = 0; i < beepCount; i++)
			{
				MessageBeep(-1);

				Thread.Sleep(500);
			}
		}
	}
}