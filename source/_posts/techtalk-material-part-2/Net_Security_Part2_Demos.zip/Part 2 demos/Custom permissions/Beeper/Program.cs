﻿using System;
using System.Runtime.InteropServices;
using BeepGateway;

namespace Beeper
{
	class Program
	{
		static void Main(string[] args)
		{
			NativeFunctions.Beep(20);

			Console.Write("Done");
			Console.Read();
		}
	}
}