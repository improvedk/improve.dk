﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Policy;

namespace EvidenceXmlWriter
{
	class Program
	{
		static void Main(string[] args)
		{
			AgeEvidence.AgeEvidence age = new AgeEvidence.AgeEvidence(23);

			Evidence evidence = new Evidence();
			evidence.AddAssembly(age);

			BinaryFormatter bf = new BinaryFormatter();
			using (var s = File.Create("ageEvidence.evidence"))
				bf.Serialize(s, evidence);

			Console.WriteLine("Done");
			Console.ReadLine();
		}
	}
}