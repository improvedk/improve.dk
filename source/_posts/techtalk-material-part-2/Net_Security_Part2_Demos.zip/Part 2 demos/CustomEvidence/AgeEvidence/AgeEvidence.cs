﻿using System;
using System.Security.Policy;
using System.Security;

namespace AgeEvidence
{
	[Serializable]
	public class AgeEvidence
	{
		int age;

		public AgeEvidence(int age)
		{
			this.age = age;
		}

		public int Age
		{
			get { return age; }
		}

		public override string ToString()
		{
			return age.ToString();
		}
	}











	public class AgeMembershipCondition : IMembershipCondition
	{
		public int Age { get; set; }

		public bool Check(Evidence evidence)
		{
			foreach (object o in evidence)
			{
				AgeEvidence ae = o as AgeEvidence;

				return returnTrueIfEvidenceAgeIsHigherThanRequirement(ae);
			}

			return false;
		}

		public IMembershipCondition Copy()
		{
			AgeMembershipCondition amc = new AgeMembershipCondition();
			amc.Age = Age;

			return amc;
		}

		public void FromXml(SecurityElement e)
		{
			Age = Convert.ToInt32(e.Attributes["age"]);
		}

		public SecurityElement ToXml()
		{
			SecurityElement se = new SecurityElement("IMembershipCondition");
			se.AddAttribute("class", this.GetType().AssemblyQualifiedName);
			se.AddAttribute("version", "1");
			se.AddAttribute("age", Age.ToString());

			return se;
		}

		public void FromXml(SecurityElement e, PolicyLevel level)
		{
			FromXml(e);
		}

		public SecurityElement ToXml(PolicyLevel level)
		{
			return ToXml();
		}















		private bool returnTrueIfEvidenceAgeIsHigherThanRequirement(object o)
		{
			return true;
		}
	}
}