﻿using System;
using System.IO;

namespace FileReader
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine(File.ReadAllText(@"C:\test.txt"));
			Console.ReadLine();
		}
	}
}