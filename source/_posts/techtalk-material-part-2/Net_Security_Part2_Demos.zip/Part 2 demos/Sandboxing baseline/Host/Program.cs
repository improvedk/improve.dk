﻿using System;
using System.IO;
using System.Security;
using System.Security.Policy;
using Contracts;

namespace Host
{
	class Program
	{
		static void Main(string[] args)
		{
			// AppDomain
			AppDomain sandbox = AppDomain.CreateDomain("AddinDomain");

			// Policy
			PolicyLevel policy = PolicyLevel.CreateAppDomainLevel();

			// Permission set
			PermissionSet permSet = new PermissionSet(policy.GetNamedPermissionSet("Execution"));
			PolicyStatement statement = new PolicyStatement(permSet);

			// Codegroup
			AllMembershipCondition allCodeMembershipCondition = new AllMembershipCondition();
			CodeGroup codeGroup = new UnionCodeGroup(allCodeMembershipCondition, statement);

			// Policy codegroup hierarki
			policy.RootCodeGroup = codeGroup;
			sandbox.SetAppDomainPolicy(policy);

			// Afvikling af plugin
			Console.WriteLine("Click to load plugin");
			Console.ReadLine();

			string assemblyPath = Path.Combine(Environment.CurrentDirectory, "FileAddin.dll");
			IAddin addin = sandbox.CreateInstanceFromAndUnwrap(assemblyPath, "FileAddin.Addin") as IAddin;

			Console.WriteLine("Click to execute plugin");
			Console.ReadLine();

			addin.Execute();

			Console.Write("Done");
			Console.ReadLine();
		}
	}
}