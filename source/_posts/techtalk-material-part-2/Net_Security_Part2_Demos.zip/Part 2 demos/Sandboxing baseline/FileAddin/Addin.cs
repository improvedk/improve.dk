﻿using System;
using System.IO;
using Contracts;

namespace FileAddin
{
	public class Addin : IAddin
	{
		public void Execute()
		{
			File.WriteAllText(@"C:\addin.txt", "Hello world from addin!");
			
			Console.WriteLine("Hello world from addin!");
		}
	}
}