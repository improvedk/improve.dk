﻿namespace Contracts
{
	public interface IAddin
	{
		void Execute();
	}
}