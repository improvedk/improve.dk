using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace SecureApplication
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			PasswordService.Service password = new SecureApplication.PasswordService.Service();

			if (password.ValidPassword(textBox1.Text))
			{
				AlgorithmService.Service algorithm = new SecureApplication.AlgorithmService.Service();

				MessageBox.Show(algorithm.AnswerToAllLife());
			}
			else
				MessageBox.Show("Error!");
		}
	}
}