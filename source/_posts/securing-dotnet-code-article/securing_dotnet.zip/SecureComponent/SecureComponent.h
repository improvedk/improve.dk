#ifdef SECURECOMPONENT_EXPORTS
#define SECURECOMPONENT_API __declspec(dllexport)
#else
#define SECURECOMPONENT_API __declspec(dllimport)
#endif

extern "C" SECURECOMPONENT_API char* AnswerToAllLife(void);