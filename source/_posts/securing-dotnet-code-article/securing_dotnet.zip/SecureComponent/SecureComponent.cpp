#include "stdafx.h"
#include "SecureComponent.h"

extern "C" SECURECOMPONENT_API char* AnswerToAllLife(void)
{
	return "Hello";
}