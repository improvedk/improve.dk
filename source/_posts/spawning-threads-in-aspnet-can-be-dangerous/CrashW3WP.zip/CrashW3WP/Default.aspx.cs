﻿using System;
using System.Web.UI;
using System.Threading;

namespace CrashW3WP
{
	public partial class _Default : Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			Response.Write("CAN HAZ W3WP.EXE?");

			new Thread(delegate()
			{
				throw new Exception("I'll not be caught by ASP.NET :(");
			}).Start();
		}
	}
}