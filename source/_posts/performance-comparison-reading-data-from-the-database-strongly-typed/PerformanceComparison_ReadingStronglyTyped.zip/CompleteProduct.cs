﻿using System;
using System.Data.Linq.Mapping;

namespace DBPerformance
{
	[Table(Name = "Production.Product")]
	public class CompleteProduct
	{
		[Column]
		public int ProductID { get; set; }
		[Column]
		public string Name { get; set; }
		[Column]
		public string ProductNumber { get; set; }
		[Column]
		public bool MakeFlag { get; set; }
		[Column]
		public bool FinishedGoodsFlag { get; set; }
		[Column]
		public string Color { get; set; }
		[Column]
		public short SafetyStockLevel { get; set; }
		[Column]
		public short ReorderPoint { get; set; }
		[Column]
		public decimal StandardCost { get; set; }
		[Column]
		public decimal ListPrice { get; set; }
		[Column]
		public string Size { get; set; }
		[Column]
		public string SizeUnitMeasureCode { get; set; }
		[Column]
		public string WeightUnitMeasureCode { get; set; }
		[Column]
		public decimal? Weight { get; set; }
		[Column]
		public int DaysToManufacture { get; set; }
		[Column]
		public string ProductLine { get; set; }
		[Column]
		public string Class { get; set; }
		[Column]
		public string Style { get; set; }
		[Column]
		public int? ProductSubcategoryID { get; set; }
		[Column]
		public int? ProductModelID { get; set; }
		[Column]
		public DateTime SellStartDate { get; set; }
		[Column]
		public DateTime? SellEndDate { get; set; }
		[Column]
		public DateTime? DiscontinuedDate { get; set; }
		[Column]
		public Guid rowguid { get; set; }
		[Column]
		public DateTime ModifiedDate { get; set; }
	}
}