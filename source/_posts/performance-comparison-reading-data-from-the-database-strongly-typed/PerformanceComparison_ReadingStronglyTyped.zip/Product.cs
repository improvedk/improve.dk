﻿using System;
using System.Data.Linq.Mapping;

namespace DBPerformance
{
	[Table(Name = "Production.Product")]
	public class Product
	{
		[Column]
		public virtual int ProductID { get; set; }
		[Column]
		public virtual string Name { get; set; }
		[Column]
		public virtual string ProductNumber { get; set; }
		[Column]
		public virtual bool MakeFlag { get; set; }
		[Column]
		public virtual short SafetyStockLevel { get; set; }
		[Column]
		public virtual decimal ListPrice { get; set; }
		[Column]
		public virtual DateTime SellStartDate { get; set; }
	}
}