using System; 
using System.Text; 
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration; 
using System.Xml; 
using System.Xml.Serialization;
using SubSonic; 
using SubSonic.Utilities;

namespace Subsonic
{
    /// <summary>
    /// Controller class for CountryRegionCurrency
    /// </summary>
    [System.ComponentModel.DataObject]
    public partial class CountryRegionCurrencyController
    {
        // Preload our schema..
        CountryRegionCurrency thisSchemaLoad = new CountryRegionCurrency();
        private string userName = string.Empty;
        protected string UserName
        {
            get
            {
				if (userName.Length == 0) 
				{
    				if (System.Web.HttpContext.Current != null)
    				{
						userName=System.Web.HttpContext.Current.User.Identity.Name;
					}

					else
					{
						userName=System.Threading.Thread.CurrentPrincipal.Identity.Name;
					}

				}

				return userName;
            }

        }

        [DataObjectMethod(DataObjectMethodType.Select, true)]
        public CountryRegionCurrencyCollection FetchAll()
        {
            CountryRegionCurrencyCollection coll = new CountryRegionCurrencyCollection();
            Query qry = new Query(CountryRegionCurrency.Schema);
            coll.LoadAndCloseReader(qry.ExecuteReader());
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Select, false)]
        public CountryRegionCurrencyCollection FetchByID(object CountryRegionCode)
        {
            CountryRegionCurrencyCollection coll = new CountryRegionCurrencyCollection().Where("CountryRegionCode", CountryRegionCode).Load();
            return coll;
        }

		
		[DataObjectMethod(DataObjectMethodType.Select, false)]
        public CountryRegionCurrencyCollection FetchByQuery(Query qry)
        {
            CountryRegionCurrencyCollection coll = new CountryRegionCurrencyCollection();
            coll.LoadAndCloseReader(qry.ExecuteReader()); 
            return coll;
        }

        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(object CountryRegionCode)
        {
            return (CountryRegionCurrency.Delete(CountryRegionCode) == 1);
        }

        [DataObjectMethod(DataObjectMethodType.Delete, false)]
        public bool Destroy(object CountryRegionCode)
        {
            return (CountryRegionCurrency.Destroy(CountryRegionCode) == 1);
        }

        
        
        
        [DataObjectMethod(DataObjectMethodType.Delete, true)]
        public bool Delete(string CountryRegionCode,string CurrencyCode)
        {
            Query qry = new Query(CountryRegionCurrency.Schema);
            qry.QueryType = QueryType.Delete;
            qry.AddWhere("CountryRegionCode", CountryRegionCode).AND("CurrencyCode", CurrencyCode);
            qry.Execute();
            return (true);
        }
        
       
    	
    	
	    /// <summary>
	    /// Inserts a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Insert, true)]
	    public void Insert(string CountryRegionCode,string CurrencyCode,DateTime ModifiedDate)
	    {
		    CountryRegionCurrency item = new CountryRegionCurrency();
		    
            item.CountryRegionCode = CountryRegionCode;
            
            item.CurrencyCode = CurrencyCode;
            
            item.ModifiedDate = ModifiedDate;
            
	    
		    item.Save(UserName);
	    }

    	
	    /// <summary>
	    /// Updates a record, can be used with the Object Data Source
	    /// </summary>
        [DataObjectMethod(DataObjectMethodType.Update, true)]
	    public void Update(string CountryRegionCode,string CurrencyCode,DateTime ModifiedDate)
	    {
		    CountryRegionCurrency item = new CountryRegionCurrency();
	        item.MarkOld();
	        item.IsLoaded = true;
		    
			item.CountryRegionCode = CountryRegionCode;
				
			item.CurrencyCode = CurrencyCode;
				
			item.ModifiedDate = ModifiedDate;
				
	        item.Save(UserName);
	    }

    }

}

