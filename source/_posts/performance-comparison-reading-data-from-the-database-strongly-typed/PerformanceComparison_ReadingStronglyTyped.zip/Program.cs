﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using Improve.Framework;
using Improve.Framework.Data;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Expression;
using SubSonic;

namespace DBPerformance
{
	class Program
	{
		private const string CONNECTION_STRING = "Data Source=.;Initial Catalog=AdventureWorks;User Id=sa;Password=sadpassword;";
		private const string ORIGINAL_COMMAND_TEXT = "SELECT TOP {rowcount} ProductID, Name, ProductNumber, MakeFlag, SafetyStockLevel, ListPrice, SellStartDate FROM Production.Product ORDER BY ProductID";
		private static string COMMAND_TEXT;
		private static int iterations = 50;
		private static int rowcount;

		#region DataReader
		private static void performDataReader()
		{
			var result = new List<Product>();

			using (SqlConnection conn = new SqlConnection(CONNECTION_STRING))
			{
				using (SqlCommand cmd = conn.CreateCommand())
				{
					cmd.CommandText = COMMAND_TEXT;

					conn.Open();
					using (SqlDataReader sqldr = cmd.ExecuteReader())
					{
						while (sqldr.Read())
						{
							Product p = new Product();
							p.ProductID = Convert.ToInt32(sqldr["ProductID"]);
							p.Name = sqldr["Name"].ToString();
							p.ProductNumber = sqldr["ProductNumber"].ToString();
							p.MakeFlag = Convert.ToBoolean(sqldr["MakeFlag"]);
							p.SafetyStockLevel = Convert.ToInt16(sqldr["SafetyStockLevel"]);
							p.ListPrice = Convert.ToDecimal(sqldr["ListPrice"]);
							p.SellStartDate = Convert.ToDateTime(sqldr["SellStartDate"]);

							result.Add(p);
						}
					}
				}
			}
		}
		#endregion

		#region DataTable
		private static DataTable getDT()
		{
			DataTable result = new DataTable();

			using (SqlConnection conn = new SqlConnection(CONNECTION_STRING))
			{
				using (SqlCommand cmd = conn.CreateCommand())
				{
					cmd.CommandText = COMMAND_TEXT;

					using (SqlDataAdapter sqlda = new SqlDataAdapter(cmd))
						sqlda.Fill(result);
				}
			}

			return result;
		}

		private static void performDataTable()
		{
			var result = new List<Product>();

			foreach (DataRow dr in getDT().Rows)
			{
				Product p = new Product();
				p.ProductID = Convert.ToInt32(dr["ProductID"]);
				p.Name = dr["Name"].ToString();
				p.ProductNumber = dr["ProductNumber"].ToString();
				p.MakeFlag = Convert.ToBoolean(dr["MakeFlag"]);
				p.SafetyStockLevel = Convert.ToInt16(dr["SafetyStockLevel"]);
				p.ListPrice = Convert.ToDecimal(dr["ListPrice"]);
				p.SellStartDate = Convert.ToDateTime(dr["SellStartDate"]);

				result.Add(p);
			}
		}
		#endregion

		#region EntityQuery
		private static void performEntityQuery()
		{
			List<Product> result;

			using (SqlConnection conn = new SqlConnection(CONNECTION_STRING))
			{
				using (DataContext dc = new DataContext(conn))
				{
					using (SqlCommand cmd = conn.CreateCommand())
					{
						cmd.CommandText = COMMAND_TEXT;

						conn.Open();
						using(SqlDataReader sqldr = cmd.ExecuteReader())
						{
							result = dc.Translate<Product>(sqldr).ToList();
						}
					}
				}
			}
		}
		#endregion

		#region LinqQuery
		private static void performLinqQuery()
		{
			List<Product> result;

			using(DataContext dc = new DataContext(CONNECTION_STRING))
			{
				result = dc.GetTable<Product>().OrderBy(p => p.ProductID).Take(rowcount).ToList();
			}
		}
		#endregion

		#region Compiled LinqQuery
		private static Func<DataContext, int, IEnumerable<Product>> compiledQuery;
		private static void performCompiledLinqQuery()
		{
			List<Product> result;

			using (DataContext dc = new DataContext(CONNECTION_STRING))
			{
				result = compiledQuery(dc, rowcount).ToList();
			}
		}
		#endregion

		#region SubsetLinqQuery
		private static void performSubsetLinqQuery()
		{
			List<Product> result;

			using (DataContext dc = new DataContext(CONNECTION_STRING))
			{
				result = dc.GetTable<CompleteProduct>().OrderBy(p => p.ProductID).Take(rowcount).Select(p => new Product() {
					ListPrice = p.ListPrice,
					ProductID = p.ProductID,
					MakeFlag = p.MakeFlag,
					Name = p.Name,
					ProductNumber = p.ProductNumber,
					SafetyStockLevel = p.SafetyStockLevel,
					SellStartDate = p.SellStartDate }).ToList();
			}
		}
		#endregion

		#region Automapped DataReader
		private static List<T> mapList<T>(SqlDataReader dr)
		{
			List<T> list = new List<T>();

			PropertyInfo[] properties = typeof(T).GetProperties();
			T t = Activator.CreateInstance<T>();

			while(dr.Read())
			{
				foreach (PropertyInfo pi in properties)
					pi.SetValue(t, dr[pi.Name], null);

				list.Add(t);
			}

			return list;
		}

		private static void performAutomappedDataReader()
		{
			List<Product> result;

			using (SqlConnection conn = new SqlConnection(CONNECTION_STRING))
			{
				using (SqlCommand cmd = conn.CreateCommand())
				{
					cmd.CommandText = COMMAND_TEXT;

					conn.Open();
					using (SqlDataReader sqldr = cmd.ExecuteReader())
					{
						result = mapList<Product>(sqldr);
					}
				}
			}
		}
		#endregion

		#region Enhanced Automapped DataReader
		private static void performEnhancedAutomappedDataReader()
		{
			List<Product> result;

			using (SqlConnection conn = new SqlConnection(CONNECTION_STRING))
			{
				using (SqlCommand cmd = conn.CreateCommand())
				{
					cmd.CommandText = COMMAND_TEXT;

					conn.Open();
					using (SqlDataReader sqldr = cmd.ExecuteReader())
					{
						result = EntityMapper.MapToEntities<Product>(sqldr).ToList();
					}
				}
			}
		}
		#endregion

		#region SubSonic SqlQuery
		private static void performSubSonicQuery()
		{
			List<Product> result =
				new Select
					(
						Subsonic.Product.ProductIDColumn.QualifiedName,
						Subsonic.Product.NameColumn.QualifiedName,
						Subsonic.Product.ProductNumberColumn.QualifiedName,
						Subsonic.Product.MakeFlagColumn.QualifiedName,
						Subsonic.Product.SafetyStockLevelColumn.QualifiedName,
						Subsonic.Product.ListPriceColumn.QualifiedName,
						Subsonic.Product.SellStartDateColumn.QualifiedName
					)
					.Top(rowcount.ToString())
					.From(Subsonic.Product.Schema)
					.OrderAsc(Subsonic.Product.ProductIDColumn.QualifiedName)
					.ExecuteTypedList<Product>();
		}
		#endregion

		#region NHibernate
		private static Configuration nhCfg;
		private static ISessionFactory nhFactory;

		private static void performNHibernateQuery()
		{
			List<Product> result;

			using (ISession session = nhFactory.OpenSession())
			{
				result = (List<Product>)session.CreateCriteria(typeof(Product)).AddOrder(Order.Asc("ProductID")).SetMaxResults(rowcount).List<Product>();
			}
		}
		#endregion

		static void Main(string[] args)
		{
			// Make sure we don't get disturbed by other processes
			Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.High;

			// We'll let NHibernate cache it's Configuration and SessionFactory as we'd probably do this in most live applications
			nhCfg = new Configuration();
			nhCfg.AddAssembly(Assembly.GetExecutingAssembly());
			nhFactory = nhCfg.BuildSessionFactory();

			foreach(int rc in new int[] { 1, 10, 100, 1000, 10000, 100000 })
			{
				Console.WriteLine("Rowcount: " + rc);
				rowcount = rc;

				// Set the rowcount
				COMMAND_TEXT = ORIGINAL_COMMAND_TEXT.Replace("{rowcount}", rowcount.ToString());

				// Make sure the enhanced automapped datareader does not use cached resources from previous run
				EntityMapper.ClearCachedMapperMethods();

				// Compile the query for the compiled linq query test
				compiledQuery = CompiledQuery.Compile<DataContext, int, IEnumerable<Product>>((DataContext dc, int takeCount) => dc.GetTable<Product>().OrderBy(p => p.ProductID).Take(takeCount));

				Console.WriteLine("performDataReader: " + CodeProfiler.ProfileAction(performDataReader, iterations, 3));
				Console.WriteLine("performDataTable: " + CodeProfiler.ProfileAction(performDataTable, iterations, 3));
				Console.WriteLine("performEntityQuery: " + CodeProfiler.ProfileAction(performEntityQuery, iterations, 3));
				Console.WriteLine("performLinqQuery: " + CodeProfiler.ProfileAction(performLinqQuery, iterations, 3));
				Console.WriteLine("performCompiledLinqQuery: " + CodeProfiler.ProfileAction(performCompiledLinqQuery, iterations, 3));
				Console.WriteLine("performSubsetLinqQuery: " + CodeProfiler.ProfileAction(performSubsetLinqQuery, iterations, 3));
				Console.WriteLine("performAutomappedDataReader: " + CodeProfiler.ProfileAction(performAutomappedDataReader, iterations, 3));
				Console.WriteLine("performEnhancedAutomappedDataReader: " + CodeProfiler.ProfileAction(performEnhancedAutomappedDataReader, iterations, 3));
				Console.WriteLine("performSubSonicQuery: " + CodeProfiler.ProfileAction(performSubSonicQuery, iterations, 3));
				Console.WriteLine("performNHibernateQuery: " + CodeProfiler.ProfileAction(performNHibernateQuery, iterations, 3));
			}

			Console.Write("Done");
			Console.Read();
		}
	}
}