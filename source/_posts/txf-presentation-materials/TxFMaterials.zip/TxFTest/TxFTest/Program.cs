﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Transactions;
using Improve.Framework.IO.Transactions;

namespace TxFTest
{
	class Program
	{
		static void Main(string[] args)
		{
			using (var ts = new TransactionScope())
			{
				TransactedFile.WriteAllText("test.txt", "Hello kitty!");

				Console.WriteLine("Pause...");
				Console.Read();

				ts.Complete();
			}

			Console.WriteLine("Done");
			Console.Read();
		}
	}
}