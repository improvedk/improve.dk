﻿using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Transactions;
using Microsoft.Win32.SafeHandles;

namespace TxFTest
{
	public class KtmTransactionHandle : SafeHandleZeroOrMinusOneIsInvalid
	{
		/// <summary>
		/// http://msdn.microsoft.com/en-us/library/aa344210(VS.85).aspx
		/// </summary>
		[ComImport]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[Guid("79427A2B-F895-40e0-BE79-B57DC82ED231")]
		private interface IKernelTransaction
		{
			void GetHandle([Out] out IntPtr handle);
		}

		/// <summary>
		/// http://msdn.microsoft.com/en-us/library/ms724211.aspx
		/// </summary>
		[DllImport("kernel32")]
		private static extern bool CloseHandle(IntPtr handle);

		private KtmTransactionHandle(IntPtr handle): base(true)
		{
			this.handle = handle;
		}

		/// <summary>
		/// http://msdn.microsoft.com/en-us/library/cc303707.aspx
		/// </summary>
		public static KtmTransactionHandle CreateKtmTransactionHandle()
		{
			if (Transaction.Current == null)
				throw new InvalidOperationException("Cannot create a KTM handle without Transaction.Current");

			return KtmTransactionHandle.CreateKtmTransactionHandle(Transaction.Current);
		}

		/// <summary>
		/// http://msdn.microsoft.com/en-us/library/cc303707.aspx
		/// </summary>
		public static KtmTransactionHandle CreateKtmTransactionHandle(Transaction managedTransaction)
		{
			IKernelTransaction tx = (IKernelTransaction)TransactionInterop.GetDtcTransaction(Transaction.Current);
			IntPtr txHandle;
			tx.GetHandle(out txHandle);

			if (txHandle == IntPtr.Zero)
				throw new Win32Exception("Could not get KTM transaction handle.");

			return new KtmTransactionHandle(txHandle);
		}

		protected override bool ReleaseHandle()
		{
			return CloseHandle(handle);
		}
	}
}