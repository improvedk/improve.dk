﻿using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
using System.Transactions;

namespace TxFTest
{
	public class TransactedFile
	{
		/// <summary>
		/// http://msdn.microsoft.com/en-us/library/aa363916(VS.85).aspx
		/// </summary>
		[DllImport("kernel32", SetLastError=true)]
		private static extern bool DeleteFileTransactedW(
			[MarshalAs(UnmanagedType.LPWStr)]string file,
			KtmTransactionHandle transaction);
		
		/// <summary>
		/// http://msdn.microsoft.com/en-us/library/aa363859(VS.85).aspx
		/// </summary>
		[DllImport("kernel32", SetLastError=true)]
		private static extern SafeFileHandle CreateFileTransactedW(
			[MarshalAs(UnmanagedType.LPWStr)]string lpFileName,
			NativeFileAccess dwDesiredAccess,
			NativeFileShare dwShareMode,
			IntPtr lpSecurityAttributes,
			NativeFileMode dwCreationDisposition,
			int dwFlagsAndAttributes,
			IntPtr hTemplateFile,
			KtmTransactionHandle hTransaction,
			IntPtr pusMiniVersion,
			IntPtr pExtendedParameter);

		[Flags]
		private enum NativeFileShare
		{
			FILE_SHARE_NONE = 0x00,
			FILE_SHARE_READ = 0x01,
			FILE_SHARE_WRITE = 0x02,
			FILE_SHARE_DELETE = 0x04
		}

		[Flags]
		private enum NativeFileMode
		{
			CREATE_NEW = 1,
			CREATE_ALWAYS = 2,
			CREATE_EXISTING = 3,
			OPEN_ALWAYS = 4,
			TRUNCATE_EXISTING = 5
		}

		[Flags]
		private enum NativeFileAccess
		{
			GENERIC_READ = unchecked((int)0x80000000),
			GENERIC_WRITE = 0x40000000
		}

		/// <summary>
		/// Transaction aware implementation of System.IO.File.Open
		/// </summary>
		/// <param name="path"></param>
		/// <param name="mode"></param>
		/// <param name="access"></param>
		/// <param name="share"></param>
		/// <returns></returns>
		public static FileStream Open(string path, FileMode mode, FileAccess access, FileShare share)
		{
			using (KtmTransactionHandle ktmHandle = KtmTransactionHandle.CreateKtmTransactionHandle())
			{
				SafeFileHandle fileHandle = CreateFileTransactedW(
					path,
					TranslateFileAccess(access),
					TranslateFileShare(share),
					IntPtr.Zero,
					TranslateFileMode(mode),
					0,
					IntPtr.Zero,
					ktmHandle,
					IntPtr.Zero,
					IntPtr.Zero);

				if (fileHandle.IsInvalid)
					throw new Win32Exception(Marshal.GetLastWin32Error());

				return new FileStream(fileHandle, access);
			}
		}

		/// <summary>
		/// Reads all text from a file as part of a transaction
		/// </summary>
		/// <param name="path"></param>
		/// <param name="contents"></param>
		/// <returns></returns>
		public static string ReadAllText(string path)
		{
			using (StreamReader reader = new StreamReader(Open(path, FileMode.Open, FileAccess.Read, FileShare.Read)))
			{
				return reader.ReadToEnd();
			}
		}

		/// <summary>
		/// Writes text to a file as part of a transaction
		/// </summary>
		/// <param name="path"></param>
		/// <param name="contents"></param>
		public static void WriteAllText(string path, string contents)
		{
			using (StreamWriter writer = new StreamWriter(Open(path, FileMode.OpenOrCreate, FileAccess.Write, FileShare.None)))
			{
				writer.Write(contents);
			}
		}

		/// <summary>
		/// Deletes a file as part of a transaction
		/// </summary>
		/// <param name="file"></param>
		public static void Delete(string file)
		{
			using (KtmTransactionHandle ktmHandle = KtmTransactionHandle.CreateKtmTransactionHandle())
			{
				if (!DeleteFileTransactedW(file, ktmHandle))
					throw new Exception("Unable to perform transacted file delete.");
			}
		}

		/// <summary>
		/// Managed -> Native mapping
		/// </summary>
		/// <param name="mode"></param>
		/// <returns></returns>
		private static NativeFileMode TranslateFileMode(FileMode mode)
		{
			if (mode != FileMode.Append)
				return (NativeFileMode)(int)mode;
			else
				return (NativeFileMode)(int)FileMode.OpenOrCreate;
		}

		/// <summary>
		/// Managed -> Native mapping
		/// </summary>
		/// <param name="access"></param>
		/// <returns></returns>
		private static NativeFileAccess TranslateFileAccess(FileAccess access)
		{
			if (access == FileAccess.Read)
				return NativeFileAccess.GENERIC_READ;
			else
				return NativeFileAccess.GENERIC_WRITE;
		}

		/// <summary>
		/// Direct Managed -> Native mapping
		/// </summary>
		/// <param name="share"></param>
		/// <returns></returns>
		private static NativeFileShare TranslateFileShare(FileShare share)
		{
			return (NativeFileShare)(int)share;
		}
	}
}