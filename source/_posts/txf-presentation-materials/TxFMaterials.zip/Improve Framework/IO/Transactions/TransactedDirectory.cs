﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using Improve.Framework.IO.Transactions.Win32Native;

namespace Improve.Framework.IO.Transactions
{
	public static class TransactedDirectory
	{
		public static bool Exists(string path)
		{
			using (KtmTransactionHandle ktmHandle = KtmTransactionHandle.CreateKtmTransactionHandle())
			{
				WIN32_FILE_ATTRIBUTE_DATA data = new WIN32_FILE_ATTRIBUTE_DATA();

				bool result = NativeMethods.GetFileAttributesTransacted(path, 0, ref data, ktmHandle);

				// Make sure we get a result, and that the FileAttributes describes a Directory
				return result && ((data.fileAttributes & FileAttributes.Directory) == FileAttributes.Directory);
			}
		}

		public static string[] GetFiles(string path)
		{
			return InternalGetChildren(path, false);
		}

		public static string[] GetDirectories(string path)
		{
			return InternalGetChildren(path, true);
		}

		internal static string[] InternalGetChildren(string path, bool directories)
		{
			using (KtmTransactionHandle ktmHandle = KtmTransactionHandle.CreateKtmTransactionHandle())
			{
				WIN32_FIND_DATA data = new WIN32_FIND_DATA();

				SafeFindHandle handle = NativeMethods.FindFirstFileTransacted(
					Path.Combine(path, "*"),
					FINDEX_INFO_LEVELS.FindExInfoStandard,
					out data,
					FINDEX_SEARCH_OPS.FindExSearchNameMatch,
					IntPtr.Zero,
					0,
					ktmHandle);

				if (handle.IsInvalid)
					throw new Win32Exception("Invalid handle: " + Marshal.GetLastWin32Error());

				IList<string> files = new List<string>();

				while (NativeMethods.FindNextFile(handle, out data))
				{
					if (data.cFileName.Equals("..") || data.cFileName.Equals("."))
						continue;

					if(directories)
					{
						if((data.dwFileAttributes & FileAttributes.Directory) == FileAttributes.Directory)
							files.Add(Path.Combine(path, data.cFileName));
					}
					else
					{
						if((data.dwFileAttributes & FileAttributes.Directory) != FileAttributes.Directory)
							files.Add(Path.Combine(path, data.cFileName));
					}
				}

				return files.ToArray();
			}
		}
	}
}