﻿using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Transactions;
using Improve.Framework.IO.Transactions.Win32Native;
using Microsoft.Win32.SafeHandles;

namespace Improve.Framework.IO.Transactions
{
	public static class TransactedFile
	{
		/// <summary>
		/// Transaction aware implementation of System.IO.File.Open
		/// </summary>
		public static FileStream Open(string path, FileMode mode, FileAccess access, FileShare share)
		{
			using (KtmTransactionHandle ktmHandle = KtmTransactionHandle.CreateKtmTransactionHandle())
			{
				SafeFileHandle fileHandle = NativeMethods.CreateFileTransactedW(
					path, // lpFileName
					TranslateFileAccess(access), // dwDesiredAccess
					TranslateFileShare(share), // dwShareMode
					IntPtr.Zero, // lpSecurityAttributes
					TranslateFileMode(mode), // dwCreationDisposition
					0, // dwFlagsAndAttributes
					IntPtr.Zero, // hTemplateFile
					ktmHandle, // hTransaction
					IntPtr.Zero, // pusMiniVersion
					IntPtr.Zero); // pExtendedParameter

				if (fileHandle.IsInvalid)
					throw new Win32Exception(Marshal.GetLastWin32Error());

				return new FileStream(fileHandle, access);
			}
		}

		/// <summary>
		/// Reads all text from a file as part of a transaction
		/// </summary>
		public static string ReadAllText(string path)
		{
			using (StreamReader reader = new StreamReader(Open(path, FileMode.Open, FileAccess.Read, FileShare.Read)))
			{
				return reader.ReadToEnd();
			}
		}

		/// <summary>
		/// Writes text to a file as part of a transaction
		/// </summary>
		public static void WriteAllText(string path, string contents)
		{
			using (StreamWriter writer = new StreamWriter(Open(path, FileMode.OpenOrCreate, FileAccess.Write, FileShare.None)))
			{
				writer.Write(contents);
			}
		}

		/// <summary>
		/// Deletes a file as part of a transaction
		/// </summary>
		public static void Delete(string file)
		{
			using (KtmTransactionHandle ktmHandle = KtmTransactionHandle.CreateKtmTransactionHandle())
			{
				if (!NativeMethods.DeleteFileTransactedW(file, ktmHandle))
					throw new Exception("Unable to perform transacted file delete.");
			}
		}

		/// <summary>
		/// Managed -> Native mapping
		/// </summary>
		private static Win32Native.NativeFileMode TranslateFileMode(FileMode mode)
		{
			if (mode != FileMode.Append)
				return (Win32Native.NativeFileMode)(int)mode;
			else
				return (Win32Native.NativeFileMode)(int)FileMode.OpenOrCreate;
		}

		/// <summary>
		/// Managed -> Native mapping
		/// </summary>
		private static Win32Native.NativeFileAccess TranslateFileAccess(FileAccess access)
		{
			if (access == FileAccess.Read)
				return Win32Native.NativeFileAccess.GENERIC_READ;
			else
				return Win32Native.NativeFileAccess.GENERIC_WRITE;
		}

		/// <summary>
		/// Direct Managed -> Native mapping
		/// </summary>
		private static Win32Native.NativeFileShare TranslateFileShare(FileShare share)
		{
			return (Win32Native.NativeFileShare)(int)share;
		}
	}
}