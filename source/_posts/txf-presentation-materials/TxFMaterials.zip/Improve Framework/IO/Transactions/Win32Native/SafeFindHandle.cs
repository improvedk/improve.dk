﻿using System;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace Improve.Framework.IO.Transactions.Win32Native
{
	internal class SafeFindHandle : SafeHandleZeroOrMinusOneIsInvalid
	{
		[DllImport("kernel32")]
		private static extern bool FindClose(IntPtr handle);

		internal SafeFindHandle(): base(true)
		{
		}

		internal SafeFindHandle(IntPtr handle): base(true)
		{
			this.handle = handle;
		}

		protected override bool ReleaseHandle()
		{
			return FindClose(handle);
		}
	}
}