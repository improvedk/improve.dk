﻿using System;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace Improve.Framework.IO.Transactions.Win32Native
{
	internal class NativeMethods
	{
		/// <summary>
		/// http://msdn.microsoft.com/en-us/library/aa363916(VS.85).aspx
		/// </summary>
		[DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern bool DeleteFileTransactedW(
			string file,
			KtmTransactionHandle transaction);

		/// <summary>
		/// http://msdn.microsoft.com/en-us/library/aa363859(VS.85).aspx
		/// </summary>
		[DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern SafeFileHandle CreateFileTransactedW(
			string lpFileName,
			NativeFileAccess dwDesiredAccess,
			NativeFileShare dwShareMode,
			IntPtr lpSecurityAttributes,
			NativeFileMode dwCreationDisposition,
			int dwFlagsAndAttributes,
			IntPtr hTemplateFile,
			KtmTransactionHandle hTransaction,
			IntPtr pusMiniVersion,
			IntPtr pExtendedParameter);

		/// <summary>
		/// http://msdn.microsoft.com/en-us/library/aa364949(VS.85).aspx
		/// </summary>
		[DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern bool GetFileAttributesTransacted(
			string name,
			int fileInfoLevel,
			ref WIN32_FILE_ATTRIBUTE_DATA lpFileInformation,
			KtmTransactionHandle hTransaction);

		/// <summary>
		/// http://msdn.microsoft.com/en-us/library/aa364422(VS.85).aspx
		/// </summary>
		[DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern SafeFindHandle FindFirstFileTransacted(
			string fileName,
			FINDEX_INFO_LEVELS fInfoLevelId,
			out WIN32_FIND_DATA lpFindFileData,
			FINDEX_SEARCH_OPS fSearchOp,
			IntPtr lpSearchFilter,
			int dwAdditionalFlags,
			KtmTransactionHandle hTransaction);

		/// <summary>
		/// http://msdn.microsoft.com/en-us/library/aa364428(VS.85).aspx
		/// </summary>
		[DllImportAttribute("kernel32.dll", CharSet = CharSet.Auto)]
		public static extern bool FindNextFile(
			SafeFindHandle hFindFile,
			out WIN32_FIND_DATA lpFindFileData);
	}
}