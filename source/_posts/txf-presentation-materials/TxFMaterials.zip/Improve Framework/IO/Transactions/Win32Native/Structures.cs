﻿using System.IO;
using System.Runtime.InteropServices;

namespace Improve.Framework.IO.Transactions.Win32Native
{
	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
	internal struct WIN32_FILE_ATTRIBUTE_DATA
	{
		internal FileAttributes fileAttributes;
		internal uint ftCreationTimeLow;
		internal uint ftCreationTimeHigh;
		internal uint ftLastAccessTimeLow;
		internal uint ftLastAccessTimeHigh;
		internal uint ftLastWriteTimeLow;
		internal uint ftLastWriteTimeHigh;
		internal int fileSizeHigh;
		internal int fileSizeLow;
	}

	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
	public struct WIN32_FIND_DATA
	{
		/// DWORD->unsigned int
		public FileAttributes dwFileAttributes;

		/// FILETIME->_FILETIME
		public FILETIME ftCreationTime;

		/// FILETIME->_FILETIME
		public FILETIME ftLastAccessTime;

		/// FILETIME->_FILETIME
		public FILETIME ftLastWriteTime;

		/// DWORD->unsigned int
		public uint nFileSizeHigh;

		/// DWORD->unsigned int
		public uint nFileSizeLow;

		/// DWORD->unsigned int
		public uint dwReserved0;

		/// DWORD->unsigned int
		public uint dwReserved1;

		/// WCHAR[260]
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
		public string cFileName;

		/// WCHAR[14]
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)]
		public string cAlternateFileName;
	}

	[StructLayout(LayoutKind.Sequential)]
	public struct FILETIME
	{
		/// DWORD->unsigned int
		public uint dwLowDateTime;

		/// DWORD->unsigned int
		public uint dwHighDateTime;
	}
}