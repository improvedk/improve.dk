﻿using System;

namespace Improve.Framework.IO.Transactions.Win32Native
{
	[Flags]
	internal enum NativeFileShare
	{
		FILE_SHARE_NONE = 0x00,
		FILE_SHARE_READ = 0x01,
		FILE_SHARE_WRITE = 0x02,
		FILE_SHARE_DELETE = 0x04
	}

	[Flags]
	internal enum NativeFileMode
	{
		CREATE_NEW = 1,
		CREATE_ALWAYS = 2,
		CREATE_EXISTING = 3,
		OPEN_ALWAYS = 4,
		TRUNCATE_EXISTING = 5
	}

	[Flags]
	internal enum NativeFileAccess
	{
		GENERIC_READ = unchecked((int)0x80000000),
		GENERIC_WRITE = 0x40000000
	}

	internal enum FINDEX_INFO_LEVELS
	{
		FindExInfoStandard,
		FindExInfoMaxInfoLevel
	}

	internal enum FINDEX_SEARCH_OPS
	{
		FindExSearchNameMatch,
		FindExSearchLimitToDirectories,
		FindExSearchLimitToDevices
	}
}