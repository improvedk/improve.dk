﻿using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows.Forms;

namespace SimpleLoadTester
{
	public partial class Form1 : Form
	{
		private bool running;
		private int successfulRequests;
		private int failedRequests;
		private string lastResult;
		private System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();

		private void button1_Click(object sender, EventArgs e)
		{
			timer.Enabled = true;
			timer.Tick += new System.EventHandler(timerTick);

			if (running)
			{
				// Stop
				running = false;
				button1.Text = "Begin";
			}
			else
			{
				// Start
				running = true;
				button1.Text = "End";

				successfulRequests = 0;
				failedRequests = 0;

				Thread t = new Thread(new ThreadStart(delegate()
				{
					while (running)
					{
						HttpWebRequest req = (HttpWebRequest)WebRequest.Create(txtUrl.Text);
						req.Timeout = 1000;
						req.KeepAlive = false;

						try
						{
							WebResponse res = req.GetResponse();
							using (StreamReader sr = new StreamReader(res.GetResponseStream()))
								lastResult = sr.ReadToEnd();

							successfulRequests++;
						}
						catch (WebException)
						{
							failedRequests++;
						}
					}
				}));
				t.Start();
			}
		}

		private void timerTick(object sender, EventArgs e)
		{
			lblFailedRequests.Text = failedRequests.ToString();
			lblSuccessfulRequests.Text = successfulRequests.ToString();
			txtResult.Text = lastResult;
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			running = false;
		}
	}
}